import java.util.Arrays;

public class UnSortedSubArray {
public static int [] unSort(int A[]) {
	int ans[];
	int temp []=Arrays.copyOf(A, A.length);
	Arrays.sort(temp);
	int l=-1, r=-1;
	for(int i=0;i<A.length;i++) {
		if(A[i]!=temp[i]) {
			l=i;
			break;
		}
	}
	for(int i=A.length-1;i>=0;i--) {
		if(A[i]!=temp[i]) {
			r=i;
			break;
		}
	}
	if(l!=-1 && r!=-1) {
		ans= new int[2];
		ans[0]=l;
		ans[1]=r;
	}else {
		ans= new int[1];
		ans[0]=-1;
	}
	return ans;
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int A[]= {1, 2, 3, 4, 5};
		System.out.println(Arrays.toString(unSort(A)));
	}

}
