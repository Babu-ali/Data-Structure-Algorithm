import java.util.Arrays;

public class ThreeSumClosest {

public static int closestSum(int A[], int B) {
	long sum=0, minDiff=Integer.MAX_VALUE;
	Arrays.sort(A);
	for(int i=0;i<A.length;i++) {
		long temp=B-A[i];
		int p1=i+1, p2=A.length-1;
		while(p1<p2) {
			if(Math.abs(A[p1]+A[p2]-temp)<minDiff) {
				sum=A[p1]+A[p2]+A[i];
				minDiff=Math.abs(A[p1]+A[p2]-temp);
				
			}
			if(A[p1]+A[p2]<temp) {
				p1++;
			}else {
				p2--;
			}
		}
	}
	return (int)sum;
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int A[]= {1,2,3};
		int B=6;
		System.out.println(closestSum(A, B));
	}

}
