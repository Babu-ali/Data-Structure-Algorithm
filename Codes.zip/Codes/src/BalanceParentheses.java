

import java.util.ArrayList;

public class BalanceParentheses 
{
	public static ArrayList<String> list=new ArrayList<String>();

	public static void generate(StringBuilder s, int open, int close){
	    if(open==0 && close==0){
	        list.add(s.toString());
	        return;
	    }
	    if(open>0){
	        s.append('(');
	        generate(s, open-1, close);
	        s.deleteCharAt(s.length()-1);
	    }
	    if(close>0){
	        if(open<close){
	            s.append(')');
	            generate(s, open, close-1);
	            s.deleteCharAt(s.length()-1);
	        }
	    }
	}
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        StringBuilder s=new StringBuilder("");
        int n=3;
        generate(s,n,n);
        for(String ele : list) {
        	System.out.println( "brackets :"+ele );
        }
        System.out.println(list.toString());
    }
}
