

import java.util.ArrayList;
import java.util.Arrays;

public class leicographicalPermutationOf0and1 {
static ArrayList<ArrayList<Integer>> list;
static ArrayList<Integer> arr;
private static void permute(int ind, int n) {
	if(ind == n) {
		list.add(new ArrayList<>(arr));
		return;
	}
	//select 0
	arr.add(0);
	permute(ind+1, n);
	arr.remove(arr.size()-1);
	//select 1
	arr.add(1);
	permute(ind+1, n);
	arr.remove(arr.size()-1);
}
public static void main(String args[]) {
	list = new ArrayList<ArrayList<Integer>>();
	arr=new ArrayList<Integer>();
	int n=3;
	permute(0,n);
	System.out.println(list);
}
}
