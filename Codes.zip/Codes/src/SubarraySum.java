import java.util.Arrays;

public class SubarraySum {

public static void subarraySum(int A[], int B) {
	int l=0, sum=A[0];
	for(int i=1;i<=A.length;i++) {
		while(sum>B && l<i-1) {
			sum-=A[l];
			l++;
		}
		if(sum==B) {
			System.out.println(sum);
			System.out.println("start index "+l);
			System.out.println("end index "+(i-1));
			break;
		}if(i<A.length) {
			sum+=A[i];
		}
	}
}

public static int[] subArraySum(int arr[], int n, int sum)
{
    long curr_sum = arr[0];
    int ans[]= {-1}, start = 0, i;
    // Pick a starting point
    for (i = 1; i <=n; i++) {
        // If curr_sum exceeds the sum,
        // then remove the starting elements
        while (curr_sum > sum && start < i - 1) {
            curr_sum = curr_sum - arr[start];
            start++;
        }

        // If curr_sum becomes equal to sum,
        // then return true
        if (curr_sum == sum) {
            return Arrays.copyOfRange(arr, start, i);
        }

        // Add this element to curr_sum
        if (i < n)
            curr_sum = curr_sum + arr[i];
    }
    return ans;
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int A[]= {42, 9, 38, 36, 48, 33, 36, 50, 38, 8, 13, 37, 33, 38, 17, 25, 50, 50, 41, 29, 34, 18, 16, 6, 49, 16, 21, 29, 41, 7, 37, 14, 5, 30, 35, 26, 38, 35, 9, 36, 34, 39, 9, 4, 41, 40, 3, 50, 27, 17, 14, 5, 31, 42, 5, 39, 38, 38, 47, 24, 41, 5, 50, 9, 29, 14, 19, 27, 6, 23, 17, 1, 22, 38, 35, 6, 35, 41, 34, 21, 30, 45, 48, 45, 37 };
		int B=100;
		System.out.println(A[16]);
		System.out.println(A[17]);
		subarraySum(A, B);
		subArraySum(A, A.length, B);
	}

}
