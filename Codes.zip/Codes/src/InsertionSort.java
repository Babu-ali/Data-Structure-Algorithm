import java.util.Arrays;

public class InsertionSort {
public static int [] insertionSor(int A[]) {
	for(int i=1;i<A.length;i++) {
		int j=i-1;
		int temp=A[i];
		while(j>=0 && A[j]>temp) {
			A[j+1]=A[j];
			j--;
		}
		A[j+1]=temp;
	}
	return A;
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int A[]= {4,3,2,1};
		insertionSor(A);
		System.out.println(Arrays.toString(A));
	}

}
