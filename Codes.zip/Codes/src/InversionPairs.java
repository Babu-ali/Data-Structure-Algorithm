import java.util.Arrays;

public class InversionPairs {
	static int count = 0;
	
static int inv_count=0;
public static long inversion(int A[], int l, int r, int[] temp) {
	long inv_cnt = 0;
	if(l>=r) {
		return 0;
	}

	int mid=(l+r)/2;
	inv_cnt+=inversion(A, l, mid, temp);
	inv_cnt+=inversion(A, mid+1, r, temp);
	inv_cnt+=merge(A, l, mid+1, r, temp);
	return inv_cnt;
}

public static int merge(int A[], int l, int mid, int r, int[] temp) {
	int i=l, j=mid, k=l, cnt=0;
	while(i<=mid-1 && j<=r) {
		if(A[i]<=A[j]) {
			temp[k] = A[i];
			k++;
			i++;
		}else {
			temp[k] = A[j];
			cnt+=(mid-i);
			j++;
			k++;
		}
	}
	
	while (i <= mid - 1){

        temp[k] = A[i];

        i++;

        k++;

    }

    

    while (j <= r){

        temp[k] = A[j];

        j++;

        k++;

    }
    for (i = l; i <= r; i++)

        A[i] = temp[i];
	return cnt;
}
//======================================

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int A[]= {45, 10, 15, 25, 50};
		int[] temp = new int[A.length];
//		inv_count=0;
		System.out.println(inversion(A, 0, A.length-1,temp));
//		System.out.println(inv_count);
//		mergeSort(A,0,A.length-1);
//		System.out.println(count);
		
		
	}

}
