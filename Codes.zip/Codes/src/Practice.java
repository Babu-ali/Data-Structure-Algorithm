import java.util.ArrayList;

public class Practice {
	final static int x=10;
	final static int y=20;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[] chars = new String[4];
		char ch=97;
		
		for(String s : chars) {
			s="S"+ch;
			System.out.println(s);
			ch++;
		}
		ArrayList<String> list = new ArrayList<String>();
		if(list.add("1")) {
			if(list.contains("1")) {
				list.add(list.indexOf("1"),"2");
			}
		}
		list.add(list.size(),"3");
		list.add("1");
		
		System.out.println(list);
		
		Object m=1;
		m +="2";
		char tab='\t';
		System.out.println(tab);
	}

}
