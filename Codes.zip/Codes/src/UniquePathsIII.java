
public class UniquePathsIII {
static int [][]A;
static int zero=0;
static int sx=0;
static int sy=0;
public static int dfs(int [][]grid, int sx, int sy, int zero) {
	if(sx<0 || sy<0 || sx>=grid.length || sy>=grid[0].length || grid[sx][sy]==-1) {
		return 0;
	}
	if(grid[sx][sy]==2) {
		return zero == -1 ? 1 : 0;
	}
	
	grid[sx][sy]=-1;
	zero--;
	
	int totalPaths= dfs(grid, sx+1, sy, zero) +
					dfs(grid, sx, sy+1, zero) +
					dfs(grid, sx-1, sy, zero) +
					dfs(grid, sx, sy-1, zero);
	
	grid[sx][sy]=0;
	zero++;
	
	return totalPaths;
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		A= new int[3][2];
		A[0][0]=2;
		A[0][1]=-1;
		A[2][0]=-1;
		A[2][1]=1;
		for(int row=0;row<A.length;row++) {
			for(int col=0;col<A[0].length;col++) {
				if(A[row][col]==1) {
					sx=row;
					sy=col;
				}
				else if(A[row][col]==0) {
					zero++;
				}
			}
		}
		System.out.println(dfs(A, sx, sy, zero));
//		dfs(A, sx, sy, zero);

	}

}
