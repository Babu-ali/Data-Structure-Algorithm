public class SmallestGoodBase {
public static long getVal(long sum , long n){
	long lo = 2 , hi = (long)Math.pow(10,9);
	while(lo<=hi){
		long mid = (lo+hi)/2;
		long currSum = ((long)Math.pow(mid,n)-1)/(mid-1) ;
		System.out.println(mid);
			if(currSum == sum){
				return mid;
			}else if(currSum < sum){
				lo = mid+1;
			}else{
				hi = mid-1;
			}
}

return -1;
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String A="13";
		Long val = Long.parseLong(A);
		long ans = val-1;
		for(int len=60 ; len>=3 ; len--){
			long currVal = getVal(val,len);
			if(currVal > 0){
				ans = currVal;
				break;
			}
		}
		System.out.println(String.valueOf(ans));
		
	}
	

}
