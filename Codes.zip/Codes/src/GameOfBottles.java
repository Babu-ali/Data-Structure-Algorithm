import java.util.Arrays;
import java.util.HashMap;

public class GameOfBottles {
public static int bottles(int A[]) {
	int n=A.length;
	Arrays.sort(A);
	int temp[]=new int[A.length];
	for(int i=0;i<A.length-1;i++) {
		for(int j=i+1;j<A.length;j++) {
			if(A[i]<A[j]) {
				if(temp[j]!=-1) {
					A[i]=-1;
					temp[j]=-1;
					n--;
					break;
				}
			}
		}

	}
	System.out.println(Arrays.toString(A));
	return (n);
}
static void min_visible_bottles(int[] arr, int n)
{
    HashMap<Integer,
            Integer> mp = new HashMap<Integer,
                                      Integer>();
    int ans = 0;
    for (int i = 0; i < n; i++)
    {
        if (mp.containsKey(arr[i]))
        {
            mp.put(arr[i], mp.get(arr[i]) + 1);
        }
        else
        {
            mp.put(arr[i], 1);
        }
        ans = Math.max(ans, mp.get(arr[i]));
    }

    System.out.print("Minimum number of " +
                  "Visible Bottles are: " +
                               ans + "\n");
    System.out.println(mp);
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int A[]= {1,1,1,2,3,4,5,5,4};
		System.out.println(bottles(A));
		
//		int n = 8;
//        int arr[] = { 1, 1, 1, 2, 3, 4, 4, 5, 5 };
 
        // Find the solution
//        min_visible_bottles(arr, n);
	}

}
