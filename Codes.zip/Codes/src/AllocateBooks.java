
public class AllocateBooks {

public static boolean isPossible(int A[], int student, int mid) {
	int studentRequired=1;
	int curr_Sum=0;
	
	for(int i=0;i<A.length;i++) {
		if(A[i]>mid) {
			return false;
		}
		
		if((curr_Sum+A[i])>mid) {
			studentRequired++;
			if(studentRequired>student) {
				return false;
			}
			curr_Sum=A[i];
		}else {
			curr_Sum+=A[i];
		}
	}
	return true;
}
public static int findPages(int A[], int student) {
	int low=Integer.MIN_VALUE;
	int high=0;
	int ans=-1;
	
	//number of books is less than no. of student
	if(A.length<student) {
		return ans;
	}
	//find Min pages can be allocate to student in worst case
	for(int i=0;i<A.length;i++) {
		if(A[i]>low) {
			low=A[i];
		}
	}
	//find Max pages that can be allocate to student in worst case
	for(int i=0;i<A.length;i++) {
		high+=A[i];
	}
	
	//apply binary search on search space(low to high)
	
	while(low<=high) {
		int mid=low+(high-low)/2;
		if(isPossible(A, student, mid)) {
			ans=mid;
			high=mid-1;
		}else {
			low=mid+1;
		}
	}
	return ans;		
}
	public static void main(String[] args) {
		int A[]= {12, 34, 67, 90};
		int B=2;
		System.out.println(findPages(A, B));
	}
}
