package SlidingWindow;

public class SubArrayMaxSum {

public static int maxSum(int A[], int k) {
	int sum=0, ans=Integer.MIN_VALUE;
	for(int i=0;i<k;i++) {
		sum+=A[i];
	}
	if(sum>ans) {
		ans=sum;
	}
	int i=0;
	while(k<A.length) {
		sum+=A[k];
		sum-=A[i];
		if(sum>ans) {
			ans=sum;
		}
		k++;
		i++;
	}
	
	
	return ans;
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int A[]= {3, -1, 1, 2, 5,-3,7};
		int B=3;
		System.out.println(maxSum(A, B));
	}

}
