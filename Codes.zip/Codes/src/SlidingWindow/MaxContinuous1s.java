package SlidingWindow;

import java.util.Arrays;

public class MaxContinuous1s {

	public static int [] maxOnes(int A[], int B) {
		int wl=0, wr=0, bestWindow=0, bestL=0, zeroCount=0;
		int ans[];
		
		while(wr<A.length) {
			
			if(zeroCount<=B) {
				if(A[wr]==0) {
					zeroCount++;
				}
				wr++;
			}else {
				if(A[wl]==0) {
					zeroCount--;
				}
				wl++;
			}
			
			if((wr-wl)>bestWindow && zeroCount<=B) {
				bestWindow=wr-wl;
				bestL=wl;
			}
		}
		
		for(int i=0;i<bestWindow;i++) {
			if(A[bestL+i]==0) {
				A[bestL+i]=1;
				System.out.println("zeroes position : "+(bestL+i));
			}
		}
		System.out.println("bestL "+bestL);
		System.out.println("bestR "+(bestWindow));
		int bestR=0;
		for(int i=bestL;i<A.length;i++) {
			if(A[i]==1) {
				System.out.println(i);
				bestR=i;
			}else {
				break;
			}
		}
		ans=new int[bestR-bestL+1];
		for(int i=0;i<ans.length;i++) {
			ans[i]=bestL;
			bestL++;
		}
		
		System.out.println(Arrays.toString(ans));
		return ans;
	}
	public static void main(String[] args) {
		// ODO Auto-generated method stub
		int A[]={1, 0, 0, 0, 1, 0, 1};
		int B=2;
		maxOnes(A,B);
	}

}
