
public class SpecialIntegerMaxSubarraySumK {
public static int binarySearch(int A[], int B) {
	int low=0, high=A.length, size=0;
	
	while(low<=high) {
		int mid=low+(high-low)/2;
		if(feasible(A,B,mid)) {
			size=mid;
			low=mid+1;
		}else {
			high=mid-1;
		}
	}
	return size;
}

//Function to check sum of subarrays of size k <= B
public static boolean feasible(int []A,int B,int k) {
	int sum=0;
	//sum of first k elements
	for(int i=0;i<k;i++) {
		sum+=A[i];
		if(sum>B) {
			return false;
		}
	}
	//sliding window to last element
	for(int i=k;i<A.length;i++) {
		sum=sum-A[i-k];
		sum=sum+A[i];
		if(sum>B) {
			return false;
		}
	}
	return true;
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int A[]= {1, 2, 3, 4, 5};
		int B=9;
		System.out.println(binarySearch(A, B));
	}

}
