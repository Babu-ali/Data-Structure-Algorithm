
public class Rectangles {

public static int rectangles(int A[], int B) {
	long ans = 0, mod = (long)(1000000000 + 7);
    int l = 0, r = A.length - 1;
    while (l < A.length && r >= 0) {
       if ((long) A[l] * A[r] < B) {
          ans = (ans + r + 1) % mod;
          l++;
       } else r--;
    }
    return (int) ans;
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int A[]= {1, 2, 3, 4, 5};
		int B=5;
		System.out.println(rectangles(A, B));
	}

}
