import java.util.Arrays;

public class TwoSumClosestToK {

public static int sumClosestToK(int A[], int k) {
	int minDiff=Integer.MAX_VALUE, sum=0;;
	int p1=0, p2=A.length-1;
	while(p1<p2) {
		if(Math.abs(A[p1]+A[p2]-k)<minDiff) {
			sum=A[p1]+A[p2];
			minDiff=Math.abs(A[p1]+A[p2]-k);
		}
		if(A[p1]+A[p2]<k) {
			p1++;
		}else if(A[p1]+A[p2]>k) {
			p2--;
		}else if(A[p1]+A[p2]==k) {
			return sum;
		}
	}
	
	return sum;
}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int A[]= {-10,-7,-3,0,3,7,12,16};
		Arrays.sort(A);
		int B=14;
		System.out.println(sumClosestToK(A, B));
	}

}
