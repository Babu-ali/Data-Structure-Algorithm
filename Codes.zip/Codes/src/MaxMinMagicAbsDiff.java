import java.util.Arrays;

public class MaxMinMagicAbsDiff {
public static int [] maxMinMagic(int A[]) {
	int ans[]=new int[2];
	Arrays.sort(A);
	int n=A.length;
	int mod=1000000007;
	long max=0;
	for(int i=n-1, j=0; j<n/2;i--, j++) {
		long diff=Math.abs((A[i]-A[j])%mod);
		max=(max+diff)%mod;
	}
	long min=0;
	for(int i=n-1;i>0;i-=2) {
		long diff=Math.abs((A[i]%mod-A[i-1]%mod+mod)%mod);
		min=(min+diff)%mod;
	}
	ans[0]=(int)max;
	ans[1]=(int)min;
	System.out.println(ans[0]);
	System.out.println(ans[1]);
	return ans;
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int A[]= {3, 11, -1, 5};
		maxMinMagic(A);
	}

}
