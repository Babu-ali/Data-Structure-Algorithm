package Socket_Programming;
import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
	
public static void client() {
	
}

public static void server(int port) {
	Socket socket = null;
	ServerSocket server = null;
	DataInputStream input = null;
	
	try {
		server = new ServerSocket(port);
		System.out.println("********Server starts***********");
		System.out.println("********waiting for a clients***********");
		socket = server.accept();
		System.out.println("********Client accepted***********");
		input = new DataInputStream(new BufferedInputStream(socket.getInputStream()));
		
		String line="";
		
		while(!line.equals("over")) {
			line = input.readUTF();
			System.out.println(line);
		}
	}catch(IOException e) {
		System.out.println(e);
	}
	System.out.println("closing the connection");
	try {
		socket.close();
		input.close();
	}catch(Exception e) {
		System.out.println(e);
	}
	
	
	
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Server.server(5000);
	}

}
