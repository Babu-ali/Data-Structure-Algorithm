package Socket_Programming;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;

public class Client {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		Socket socket = new Socket("127.0.0.1", 5000);
//		DataInputStream input = new DataInputStream(System.in);
		BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
		DataOutputStream out = new DataOutputStream(socket.getOutputStream());
		
		String line="";
		while(!line.equals("over")) {
			line=input.readLine();
			out.writeUTF(line);
		}
		input.close();
		out.close();
		socket.close();

	}

}
