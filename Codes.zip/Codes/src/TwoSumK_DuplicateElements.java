
public class TwoSumK_DuplicateElements {

	public static int sumK(int A[], int k) {
		int p1=0, p2=A.length-1;
	    long count=0;
		while(p1<p2) {
			long sum=(A[p1]+A[p2])%1000000007;
			System.out.println("sum :"+sum);
			if(sum==k) {
				if(A[p1]!=A[p2]) {
					int count_p1=0, left=p1;
					while(A[p1]==A[left]) {
						count_p1++;
						p1++;
					}
					int count_p2=0, right=p2;
					while(A[p2]==A[right]) {
						count_p2++;
						p2--;
					}
					count=(count+(count_p1*count_p2));
				}else {
					long n=p2-p1+1;
					System.out.println("n :"+n);
					long combination=(n*(n-1))/2;
					count=(count+combination)%1000000007;
					return (int)(count%1000000007);
				}
			}else if(sum>k) {
				p2--;
			}else if(sum<k) {
				p1++;
			}
		}
		return (int)count;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int A[]= {4629666, 4629666, 4629666, 4629666, 4629666, 4629666, 4629666, 4629666, 4629666, 4629666, 4629666, 4629666, 4629666, 4629666, 4629666, 4629666, 4629666, 4629666, 4629666, 4629666, 4629666, 4629666, 4629666, 4629666, 4629666, 4629666, 4629666, 4629666, 4629666, 4629666, 4629666, 4629666, 4629666, 4629666, 4629666, 4629666, 4629666, 4629666, 4629666, 4629666, 4629666, 4629666, 4629666, 4629666, 4629666, 4629666, 4629666, 4629666, 4629666, 4629666, 4629666, 4629666, 4629666, 4629666, 4629666, 4629666, 4629666, 4629666, 4629666, 4629666, 4629666, 4629666, 4629666, 4629666, 4629666, 4629666, 4629666, 4629666, 4629666, 4629666, 4629666, 4629666, 4629666, 4629666, 4629666, 4629666, 4629666, 4629666, 4629666, 4629666, 4629666, 4629666, 4629666};
		int k=9259332;
		System.out.println(A.length);
		System.out.println(sumK(A,k));
//		System.out.println(fact(5));
	}

}
