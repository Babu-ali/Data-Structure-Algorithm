import java.util.ArrayList;
import java.util.Arrays;

public class KClosestPointToOrigin {
public static int [][] kClosestPoint(int A[][], int B) {
	int distance[]=new int[A.length];
	
	ArrayList<ArrayList<Integer>> ans = new ArrayList<>();
	int ansArray[][];
	for(int i=0;i<A.length;i++) {
		int x=A[i][0];
		int y=A[i][1];
		
		distance[i]=(x*x)+(y*y);
	}
	Arrays.sort(distance);
	int minDistance=distance[B-1];
	for(int i=0;i<A.length;i++) {
		int x=A[i][0];
		int y=A[i][1];
		int tempDistance=(x*x)+(y*y);
		if(tempDistance<=minDistance) {
				ans.add(new ArrayList<>(Arrays.asList(x,y)));
	
	}
	}
	ansArray=new int[ans.size()][ans.size()+1];
	int i=0;
	for(ArrayList<Integer> l : ans) {
		ansArray[i][0]=l.get(i);
		ansArray[i][1]=l.get(i+1);
		i++;
	}
	return ansArray;
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int A[][]=new int[2][2];
		int B=1;
		A[0][0]=1;
		A[0][1]=3;
		A[1][0]=-2;
		A[1][1]=2;
		kClosestPoint(A, B);
	}

}
