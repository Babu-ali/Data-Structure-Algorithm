import java.util.Arrays;

public class AggresiveCows {
public static boolean check(int A[], int distance, int cows) {
	int cowsPlaced=1;
	int prePosition=A[0];
	
	for(int i=1;i<A.length;i++) {
		if(Math.abs(A[i]-prePosition)>=distance) {
			cowsPlaced++;
			prePosition=A[i];
		}
	}
	if(cowsPlaced>=cows) {
		return true;
	}
	return false;
}
public static int binarySearch(int A[], int cows) {
	int low=A[1]-A[0], high=A[A.length-1]-A[0], ans=1;
	for(int i=2;i<A.length;i++) {
		if((A[i]-A[i-1])<low) {
			low=(A[i]-A[i-1]);
		}
	}
	
	while(low<=high) {
		int mid=low+(high-low)/2;
		if(check(A, mid, cows)) {
			ans=mid;
			low=mid+1;
		}else {
			high=mid-1;
		}
	}
	return ans;
}
	public static void main(String arg[]) {
		int A[]= {5, 17, 100, 11 };
		Arrays.sort(A);
		int B=2;
		System.out.println(binarySearch(A, B));
	}
}
