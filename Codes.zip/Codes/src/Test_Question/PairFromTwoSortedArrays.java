package Test_Question;

public class PairFromTwoSortedArrays {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr1[]= {1, 4, 5, 7};
		int arr2[]= {10, 20, 30, 40};
		
		int i=0, j=arr2.length-1;
		int p1=0,p2=0;
		int min = Integer.MAX_VALUE;
		int k=50;
		
		while(i<arr1.length && j>=0) {
			int sum = arr1[i]+arr2[j];
			int diff = Math.abs(sum-k);
			
			if(diff<min) {
				min = diff;
				p1=i;
				p2=j;
			}
			if(sum>k) {
					j--;
			}else {
				i++;
			}
		}
		System.out.println(min);
		System.out.println(arr1[p1] +" "+ arr2[p2]);
	}

}
