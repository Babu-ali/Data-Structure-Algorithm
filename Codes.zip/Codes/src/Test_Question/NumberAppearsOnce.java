package Test_Question;

public class NumberAppearsOnce {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[] = { 1, 1, 3, 3, 4, 5, 5, 7, 7, 8, 8};
		
		int low = 0, high = arr.length-1;
		int mid;
		if(arr.length==1) {
			System.out.println("ans "+arr[0]);
			return ;
		}
		
		if(arr[0]!=arr[1]) {
			System.out.println("ans "+arr[0]);
			return ;
		}
		if(arr[arr.length-1]!=arr[arr.length-2]) {
			System.out.println("ans "+arr[arr.length-1]);
			return ;
		}
		while(low<=high) {
			mid=low + (high-low)/2;
			if(arr[mid]!=arr[mid+1] && arr[mid]!=arr[mid-1]) {
				System.out.println("ans "+arr[mid]);
				return;
			}
			if(mid%2==0 && arr[mid+1]==arr[mid])
				low=mid+1;
			else if(mid%2==0 && arr[mid-1]==arr[mid])
				high=mid-1;
			
			else if(mid%2!=0 && arr[mid+1]==arr[mid])
				high=mid-1;
			else if(mid%2!=0 && arr[mid-1]==arr[mid])
				low=mid+1;
		}
	}

}
