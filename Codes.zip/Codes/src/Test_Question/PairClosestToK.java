package Test_Question;

public class PairClosestToK {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int arr[]= {1, 3, 4, 7, 10};
		int i=0;
		int j=arr.length-1;
		
		int p1=0, p2=0;
		int min=Integer.MAX_VALUE;
		int k=15;
		
		while(i!=j) {
			int sum = arr[i]+arr[j];
			int diff=Math.abs(sum-k);
			if(diff<min) {
				min=Math.min(min, diff);
				p1=i;
				p2=j;
			}
			
			if(arr[j]>=k || sum>=k) {
				j--;
			}else {
				i++;
			}
			
		}
		System.out.println(min);
		System.out.println("i "+p1 +"j "+p2);
		

	}

}
