import java.util.Arrays;

public class KthSmallestElement {
public static int kthSmallest(int []A, int B) {
	
	for(int i=0;i<B;i++) {
		int min=Integer.MAX_VALUE;
		int minPos=-1;
		for(int j=i;j<A.length;j++) {
			if(A[j]<min) {
				min=A[j];
				minPos=j;
			}
		}
		int temp=0;
		temp=A[i];
		A[i]=A[minPos];
		A[minPos]=temp;
	}
	return A[B-1];
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int A[]= {2, 1, 4, 3, 2};
		int B=3;
		System.out.println(kthSmallest(A,B));
		System.out.println(Arrays.toString(A));

	}

}
