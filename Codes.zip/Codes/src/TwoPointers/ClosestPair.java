package TwoPointers;
import java.util.Arrays;
public class ClosestPair {

	public static int[] closestPair(int A[], int B[], int C) {
		int ans[]=new int[2];
		long diff=Integer.MAX_VALUE;
		int p1=0,p2=B.length-1;
		int first = A[0]; 
        int second = B[B.length-1];
		while(p1<A.length && p2>=0) {
			long sum=Math.abs(A[p1]+B[p2]-C);
			if(sum==diff && first==A[p1] ) {
				second=B[p2];
			}
			if(sum<diff) {
				diff=sum;
					first=A[p1];
					second=B[p2];
			}
			if((A[p1]+B[p2])<C) {
				p1++;
			}else {
				p2--;
			}
		}
		System.out.println(Arrays.toString(new int[]{first, second}));
		return ans;
	}

	 public static  int[] solve(int[] A, int[] B, int C) {

	        int low = 0;
	        int high = B.length-1;
	        int first = A[0]; 
	        int second = B[B.length-1];
	        //diff
	        int min = Math.abs(A[low]+B[high]-C);

	        while(low < A.length && high >= 0)
	        {
	            int sum = A[low] +B[high];
	            int abs = Math.abs(A[low]+B[high]-C);

	            if(abs == min && A[low] == first)
	            {
	                second = B[high];
	            }
	            if(abs < min)
	            {
	                min = abs;
	                first = A[low];
	                second = B[high];
	            }
	            if(sum >= C)
	                high--;
	            else
	                low++;
	        }
	        System.out.println(Arrays.toString(new int[]{first, second}));
	        return new int[]{first, second};
	    }
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int A[]= {1, 2, 3, 4, 5};
		int B[]= {2,4,6,8};
		int C=9;
		closestPair(A, B, C);
		solve(A, B, C);
	}
}
