package TwoPointers;

public class SubarraySumofK {

	public static boolean subarraySumK(int A[], int k) {
		int pre[]=new int[A.length+1];
//		pre[0]=A[0];
		for(int i=0;i<A.length;i++) {
			pre[i+1]=pre[i]+A[i];
		}
		int p1=0, p2=1;
		while(p1<pre.length && p2<pre.length) {
			if(pre[p2]-pre[p1]==k) {
				System.out.println("p1 "+(p1));
				System.out.println("p2 "+(p2-1));
				return true;
				
			}
			if(pre[p2]-pre[p1]>k) {
				p1++;
			}else {
				p2++;
			}
			
		}
		return false;
	}
	public static void main(String args[]) {
		int A[]= {3,2,5,0,1,8,6,2,10};
		int k=3;
		System.out.println(subarraySumK(A, k));
	}
}
