package TwoPointers;

public class ArrayThreePointers {

	public static int arrayThreePointers(int A[], int B[], int C[]) {
		int min=Integer.MAX_VALUE;
		int p1=0, p2=0, p3=0;
		
		while(p1<A.length && p2<B.length && p3<C.length) {
			int maxNumber=Math.max(A[p1], Math.max(B[p2], C[p3]));
			int minNumber=Math.min(A[p1], Math.min(B[p2], C[p3]));
			if((maxNumber-minNumber)<min) {
				min=(maxNumber-minNumber);
			}
			if(minNumber==A[p1]) {
				p1++;
			}else if(minNumber==B[p2]) {
				p2++;
			}else {
				p3++;
			}
		}
		return min;
	}
	
	public static void main(String args[]) {
		int A[]= {1, 4, 10};
		int B[]= {2, 15, 20};
		int C[]= {10, 12};
		System.out.println(arrayThreePointers(A, B, C));
	}
}
