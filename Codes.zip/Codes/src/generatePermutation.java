

import java.util.ArrayList;
import java.util.Arrays;

public class generatePermutation {
public static ArrayList<String> list=new ArrayList<String>();
public static void recursionPermutation(ArrayList<ArrayList<Integer>> ans, ArrayList<Integer> ds, boolean []freq, int arr[]) {
	if(ds.size()==arr.length) {
		ans.add(new ArrayList<>(ds));
		return;
	}
	for(int i=0;i<arr.length;i++) {
		if(freq[i]==false) {
			freq[i]=true;
			ds.add(arr[i]);
			recursionPermutation(ans, ds, freq, arr);
			ds.remove(ds.size()-1);
			freq[i]=false;
		}
	}
}
public static void main(String args[]) {
	int []A= {1,2,3};
	int ansArray[][];
	ArrayList<ArrayList<Integer>> ans=new ArrayList<ArrayList<Integer>>();
	ArrayList<Integer> ds = new ArrayList<Integer>();
	boolean freq[]=new boolean[A.length];
	Arrays.fill(freq, false);
	recursionPermutation(ans, ds, freq, A);
	System.out.println(ans.toString());
	System.out.println((ans.get(0).size()));
	System.out.println(ans.size());
	ansArray=new int[(ans.size())][(ans.get(0).size())];
	for(int i=0;i<ans.size();i++) {
		Object[] arr=ans.get(i).toArray();
		int j=0;
		for(;j<arr.length;j++) {
			ansArray[i][j]=(int) arr[j];
			System.out.println(ansArray[i][j]);
		}
	}
//	System.out.println(ansArray[0][0]);
}
}
