
public class RotatedSortedArraySearch {
public static int findKSorted(int A[], int B) {
	int k=0;
	int low=0, high=A.length-1, mid=low+(high-low)/2;
	if(A.length==1) {
		return (k=1);
	}
	while(low<=high) {
		mid=low+(high-low)/2;
		if(A[mid]<A[0]) {
			k=mid;
			high=mid-1;
		} else if(A[mid]>A[0]) {
			low=mid+1;
		}
	}
	
	return k;
}
public static int binarySearch(int A[],int low, int high, int B) {
	int mid=low+(high-low)/2;
	int index=-1;
	while(low<=high) {
		mid=low+(high-low)/2;
		System.out.println("mid :"+mid);
		if(A[mid]==B) {
			return index=mid;
		}else if(A[mid]<B) {
			low=mid+1;
		}else {
			high=mid-1;
		}
	}
	return index;
}
public static int rotatedSortedSearch(int A[], int B, int k) {
	int index=-1;
	
	index=binarySearch(A, 0, k-1, B);
	if(index!=-1) {
		return index;
	}else {
		index=binarySearch(A, k, A.length-1, B);
	}
	
	return index;
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int A[]= { 1, 7, 67, 133, 178};
		int B=178;
		int k=findKSorted(A,B);
		System.out.println(rotatedSortedSearch(A, B, k));
		
	}

}
