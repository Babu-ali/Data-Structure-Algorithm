
public class TrappedWater_2_Pointers {

public static int trappedWater(int A[]) {
	int area=Integer.MIN_VALUE;
	int h=0, w=0, p1=0, p2=A.length-1;
	while(p1<p2) {
		h=Math.min(A[p1], A[p2]);
		w=p2-p1;
		area=Math.max(area, (h*w));
		if(A[p1]<A[p2]) {
			p1++;
		}else {
			p2--;
		}
		
	}
	
	return area;
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int A[]= {2,3,4,7,3,6,5,4,3,1};
		System.out.println(trappedWater(A));

	}

}
