import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

public class combinationSum {
public static ArrayList<ArrayList<Integer>> combination(ArrayList<Integer> A, int target, ArrayList<ArrayList<Integer>> list){
//		Set<ArrayList<Integer>> list= new HashSet<ArrayList<Integer>>();
	    ArrayList<ArrayList<Integer>> ans= new ArrayList<ArrayList<Integer>>();
		ArrayList<Integer> temp = new ArrayList<Integer>();
		func(0, target, A, temp, list);
	    for(ArrayList<Integer> l : list){
	        ans.add(new ArrayList<>(l));
	    }
		return ans;
}
public static void func(int idx, int target, ArrayList<Integer> A, ArrayList<Integer> temp, ArrayList<ArrayList<Integer>> list) {
	if(idx==A.size()) {
		if(target==0) {
//			Collections.sort(temp);
			if(!list.contains(temp))
				list.add(new ArrayList<>(temp));
	}
		return;
	}
	
	if(A.get(idx)<=target) {
		temp.add(A.get(idx));
		func(idx, target-A.get(idx), A, temp, list);
		temp.remove(temp.size()-1);
	}
	func(idx+1, target, A, temp, list);
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<ArrayList<Integer>> list=  new ArrayList<ArrayList<Integer>>();
		ArrayList<Integer> A = new ArrayList<Integer>();
		A.add(8);
		A.add(10);
		A.add(6);
		A.add(11);
		A.add(1);
		A.add(16);
		A.add(8);
		Collections.sort(A);
		System.out.println(A);
		System.out.println(combination(A, 28, list));
//		Collections.sort(list, new Comparator<ArrayList<Integer>>() {
//
//			@Override
//			public int compare(ArrayList<Integer> o1, ArrayList<Integer> o2) {
//				// TODO Auto-generated method stub
//				int len=0;
//				if(o1.size()>o2.size()) {
//					len=o2.size();
//				}else {
//					len=o1.size();
//				}
//				for(int i=0;i<len;i++) {
//					if(o1.get(i)!=o2.get(i)) {
//						return o1.get(i).compareTo(o2.get(i));
//					}
//				}
//				return 0;
//			}
//		});

	}

}
