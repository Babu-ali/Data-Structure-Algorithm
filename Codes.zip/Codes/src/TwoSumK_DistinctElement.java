
public class TwoSumK_DistinctElement {

public static boolean checkPairs(int A[], int k) {
	int p1=0, p2=A.length-1, count=0;
	while(p1<=p2) {
		int sum=A[p1]+A[p2];
//		System.out.println("sum :"+sum);
		if(sum==k) {
			System.out.println("p1 :"+A[p1]);
			System.out.println("p2 :"+A[p2]);
			count++;
			p1++;
			p2--;
//			return true;
		}else if(sum>k) {
			p2--;
		}else if(sum<k) {
			p1++;
		}
	}
	System.out.println("count :"+count);
	return count>0;
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int A[]= {-3, 0, 1, 3, 5, 7, 12, 14, 18, 25};
		int k=17;
		System.out.println(checkPairs(A, k));
	}

}
