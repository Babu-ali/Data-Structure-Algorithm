import java.util.ArrayList;

public class palindromePartitioning {
public static ArrayList<ArrayList<String>> partition(String s) {
	ArrayList<ArrayList<String>> list = new ArrayList<ArrayList<String>>();
	ArrayList<String> path = new ArrayList<String>();
	palindromePartition(0,s,list, path);
	return list;
}
public static void palindromePartition(int idx, String s, ArrayList<ArrayList<String>> list, ArrayList<String> path ) {
	if(idx==s.length()) {
		list.add(new ArrayList<>(path));
		return;
	}
	for(int i=idx;i<s.length();i++) {
		if(isPalindrome(s, idx, i)) {
			path.add(s.substring(idx, i+1));
			palindromePartition(i+1, s, list, path);
			path.remove(path.size()-1);
		}
	}
	
}
public static boolean isPalindrome(String s, int start, int end) {
	while(start<=end) {
		if(s.charAt(start++)!=s.charAt(end--)) {
			return false;
		}
	}
	return true;
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="aab";
		System.out.println(partition(s));
	}

}
