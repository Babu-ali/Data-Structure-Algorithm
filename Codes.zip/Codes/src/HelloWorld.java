import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;

public class HelloWorld {
private static HashMap<Integer,Integer> map;
private static ArrayList<HashMap<Integer, Integer>> F;
private static ArrayList<Integer> temp;
private static ArrayList<Integer> storeSubSequence;
private static ArrayList<ArrayList<Integer>> ans;
private static Object[] uniqueValues;
private static void generateFrequency(int A[], HashMap<Integer,Integer> map) {
	for(int i=0;i<A.length;i++) {
		if(!map.containsKey(A[i])) {
			map.put(A[i], 1);
		}else {
			map.put(A[i], (map.get(A[i])+1));
		}
	}
}

private static void hashToArray(HashMap<Integer,Integer> map) {
	Object[] keys=map.keySet().toArray();
	for(int i=0;i<keys.length;i++) {
		HashMap<Integer, Integer> temp=new HashMap<Integer, Integer>();
		temp.put((int)keys[i], map.get(keys[i]));
		F.add(temp);
	}
}

private static void generate(int index, ArrayList<HashMap<Integer, Integer>> F, ArrayList<Integer> temp) {
	if(index == F.size()) {
		System.out.println(temp);
		ArrayList<Integer> storeSubSequence = new ArrayList<Integer>();
		for(int i=0;i<temp.size();i++) {
			if(temp.get(i)!=0) {
				for(int j=0;j<temp.get(i);j++) {
					storeSubSequence.add((int)uniqueValues[i]);
				}
			}
		}
		ans.add(new ArrayList<Integer>(storeSubSequence));
		return;
	}
	Collection<Integer> val=F.get(index).values();
	Object[] values=val.toArray();
	for(int i=0;i<=(int)values[0];i++) {
		temp.add(i);
		generate(index+1, F, temp);
		temp.remove(temp.size()-1);
	}
}

private static void sortAnswer(ArrayList<ArrayList<Integer>> list) {
	Collections.sort(list, new Comparator<ArrayList<Integer>>() {
		public int compare(ArrayList<Integer> list1, ArrayList<Integer> list2) {
			int len=0;
			if(list1.size()<list2.size()) {
				len=list1.size();
			}else {
				len=list2.size();
			}
			int check=0;
			for(int i=0;i<len;i++) {
				check=list1.get(i).compareTo(list2.get(i));
				if(check==0){
					
				}else {
					return list1.get(i).compareTo(list2.get(i));
				}
			}
			return check;
		}
	});
}
public static void main(String[] args) {
		// TODO Auto-generated method stub
		int A[]= {1,1,2,3};
		map=new HashMap<Integer,Integer>();
		F=new ArrayList<HashMap<Integer, Integer>>();
		temp=new ArrayList<Integer>();
		ans= new ArrayList<ArrayList<Integer>>();
		generateFrequency(A, map);
		hashToArray(map);
		uniqueValues=map.keySet().toArray();
		generate(0, F, temp);
		System.out.println(map);
		sortAnswer(ans);
		System.out.println(ans);
		
	}

}
