
public class PaintersPartitionProblem {

	public static long paintersPaint(int A, int B, int C[]) {
		long low=Integer.MIN_VALUE, high=0, ans=0;
		for(int i=0;i<C.length;i++) {
			high=(high+C[i]);
			if(C[i]>low){
				low=C[i];
			}
		}
		while(low<=high) {
			long mid=(low+(high-low)/2);
			if(isPossible(C, A, mid)) {
				ans=mid;
				high=mid-1;
			}else {
				low=mid+1;
			}
		}
		// ans%=10000003;
		return (ans*B)%10000003;
	}

	public static boolean isPossible(int C[], long A, long mid) {
		int painterRequired=1;
		int curr_time=0;
		
		for(int i=0;i<C.length;i++) {
			if(C[i]>mid) {
				return false;
			}
			curr_time+=C[i];
			if(curr_time>mid) {
				painterRequired++;
				curr_time=C[i];
			}
		}
		if(painterRequired>A) {
			return false;
		}
		return true;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
				int A = 3;
				int B = 10;
				int C[] = {185, 186, 938, 558, 655, 461, 441, 234, 902, 681};
				
				System.out.println(paintersPaint(A,B,C));
				
	}

}
