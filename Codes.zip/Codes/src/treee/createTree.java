package treee;

import java.util.ArrayList;

public class createTree {
	Node root;
	
	class Node {
		int data;
		Node left;
		Node right;
		
		 Node(int data) {
			this.data = data;
			left = null;
			right = null;
		}
	}
	
	public static void main(String[] args) {
		createTree tree = new createTree();
		
		tree.root = tree.new Node(1);
		tree.root.left = tree.new Node(2);
		tree.root.right = tree.new Node(3);
		tree.root.left.left = tree.new Node(4);
		tree.root.left.right = tree.new Node(5);
	}
	
	void postOrderTraversal(Node root) {
		ArrayList<Integer> list = new ArrayList<>();
		
		
	}

}
