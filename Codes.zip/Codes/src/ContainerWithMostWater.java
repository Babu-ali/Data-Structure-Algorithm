
public class ContainerWithMostWater {

public static int mostWater(int A[]) {
	long area=Integer.MIN_VALUE, h, w;
	int p1=0, p2=A.length-1;
	
	if(A.length==1) {
		return 0;
	}
	while(p1<p2) {
		h=Math.min(A[p1], A[p2]);
		w=p2-p1;
		area=Math.max(area, (h*w));
		if(A[p1]<A[p2]) {
			p1++;
		}else {
			p2--;
		}
	}
	return (int)area;
}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int A[]= {1,5,4,3};
		System.out.println("Water :"+mostWater(A));
	}

}
