package trie;

public class MaxXOR {
	
static class TrieNode{
	TrieNode zero;
	TrieNode one;
	int number;
	boolean isTerminal;
}



	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
