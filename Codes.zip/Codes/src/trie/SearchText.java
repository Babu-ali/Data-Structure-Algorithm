package trie;

import java.util.ArrayList;
import java.util.Arrays;

public class SearchText {
	static TrieNode root;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		root = new TrieNode();
		ArrayList<String> list = new ArrayList<String>();
		ArrayList<String> listInput = new ArrayList<String>();
		ArrayList<Integer> ans = new ArrayList<Integer>();
		
		list.add("ab");
		list.add("abc");
		list.add("abcd");
		list.add("abcde");
		list.add("abcdef");
		list.add("abcdeg");
		list.add("abcdeh");
		
		listInput.add("a");
		listInput.add("b");
		listInput.add("ab");
		listInput.add("abcd");
		
		for(String s: list) {
			insert(s);
		}
		
		for(String s: listInput) {
			ans.add(checkString(s));
		}
			
		System.out.println(ans);

	}
	
	static class TrieNode{
		boolean isEndOfWord;
		TrieNode children[];
		int count;
		
		TrieNode(){
			isEndOfWord=false;
			children= new TrieNode[26];
			count=0;
			Arrays.fill(children, null);
		}
	}
	
	static void insert(String word) {
		TrieNode pCrawl = root;
		int index;
		
		for(int i=0;i<word.length();i++) {
			index=word.charAt(i)-'a';
			if(pCrawl.children[index]==null) {
				pCrawl.children[index]= new TrieNode();
			}
			pCrawl = pCrawl.children[index];
			pCrawl.count++;
		}
		pCrawl.isEndOfWord=true;
		
	}
	
	static int checkString(String word) {
			TrieNode curr = root;
			int idx=0;
			for(int i=0;i<word.length();i++) {
				idx = word.charAt(i)-'a';
					if(curr.children[idx]==null) {
						return 0;
					}
					curr=curr.children[idx];
			}
			return curr.isEndOfWord ? 1 : 0;
	}

	
//	A : [ "ab", "abc", "abcd", "abcde", "abcdef", "abcdefg" ]
//			B : [ "a", "b", "ab", "abcd" ]
}
