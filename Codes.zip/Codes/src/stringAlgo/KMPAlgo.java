package stringAlgo;

import java.util.Arrays;

public class KMPAlgo {
	static void kmpSearch(String A, String pat, int[] lps) {
		int i=0, j=0;
		int n=A.length();
		int m=pat.length();
		
		while(i<n) {
			if(A.charAt(i)==pat.charAt(j)) {
				i++;
				j++;
			}else {
				if(j>0) {
					j=lps[j-1];
				}else {
					i++;
				}
			}
			if(j==m) {
				System.out.println(A.substring(i-j, i));
				j=lps[j-1];
			}
		}
	}
	 static void createLps(String A, int[] lps){
	        int i=1, j=0;
	        while(i<A.length()){
	            if(A.charAt(i)==A.charAt(j)){
	                lps[i]=j+1;
	                i++;
	                j++;
	            }
	            else{
	                if(j>0)
	                    j=lps[j-1];
	                else
	                    i++;
	            }
	        }
	    }
	 
	 static void computeLPS(String A, int[] lps) {
		 int j=0, i=1;
		 while(i<A.length()) {
			 if(A.charAt(j)==A.charAt(i)) {
				 j++;
				 lps[i]=j;
				 i++;
			 }else {
				 if(j>0) {
					 j=lps[j-1];
				 }else {
					 i++;
				 }
			 }
		 }
	 }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String A="onionsonions";
		String pat="onion";
//		StringBuilder sb = new StringBuilder(A);
//        sb.reverse();
//        String palin = A+"$"+sb;
//        int[] lps = new int[palin.length()];
        int[] lps = new int[pat.length()];
        computeLPS(pat, lps);
//        createLps(palin, lps);
        System.out.println(Arrays.toString(lps));
//        System.out.println(A.length()-lps[lps.length-1]);
        kmpSearch(A,pat,lps);

	}

}
