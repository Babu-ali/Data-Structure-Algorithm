package stringAlgo;

public class SmallestPrefixofAandB {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String A="dkfjlkdf";
		String ans=new String(""+A.charAt(0));
	}

}
