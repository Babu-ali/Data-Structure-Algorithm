package stringAlgo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class LongestCommonPrefix {

	public static String longestCommonPrefix(List<String> A) {
        String prefix = "";
        if(A.size() == 0) return prefix;
        if(A.size() == 1) return A.get(0);
        //abcde
        //abcd
        String ref = A.get(0);
        if(ref.length() == 0 ) return prefix;
       
        boolean flag = false;
        for(int i=0; i<ref.length(); i++){
            char c = ref.charAt(i);
            for(String str : A){
               if( i<str.length()){
                   if(str.charAt(i) !=  c){
                	flag = true;
                    break;
                   }
               } else {
                   flag = true;
                   break;
               }
        }
        if(!flag)
                prefix += c;
        }
        return prefix;
    }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<String> list = new ArrayList<String>();
		list.add("abcde");
		list.add("abcd");
		System.out.println(longestCommonPrefix(list));
		int arr[]= {1,2,3};
		String s[]= {"geezsforgeezs","geezs","geez","geezer"};
		Arrays.sort(s);
		System.out.println(Arrays.toString(s));
		
		
	}

}
