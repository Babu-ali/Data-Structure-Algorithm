package stringAlgo;

import java.util.Arrays;

public class BoringSubstring {
private static int boringSubstring(String A) {
	StringBuilder odd= new StringBuilder();
	StringBuilder even= new StringBuilder();
	for(int i=0;i<A.length();i++) {
		if(A.charAt(i)%2==0) {
			even.append(A.charAt(i));
		}else {
			odd.append(A.charAt(i));
		}
	}
	
	char oddChar[]=odd.toString().toCharArray();
	char evenChar[]=even.toString().toCharArray();
	Arrays.sort(oddChar);
	Arrays.sort(evenChar);

	System.out.println(Arrays.toString(oddChar));
	System.out.println(Arrays.toString(evenChar));
	
	odd=new StringBuilder(new String(oddChar));
	even=new StringBuilder(new String(evenChar));
	
	if(check(odd.toString()+even.toString())) {
		return 1;
	}else if(check(even.toString()+odd.toString())) {
		return 1;
	}
	return 0;
}

private static boolean check(String s) {
	for(int i=0;i+1<s.length();++i) {
		if(Math.abs(s.charAt(i)-s.charAt(i+1)) == 1) {
			return false;
		}
	}
	return true;
}

public static int solve(String A) {
int emin = Integer.MAX_VALUE;
int emax = Integer.MIN_VALUE;
int omin = Integer.MAX_VALUE;
int omax = Integer.MIN_VALUE;

for(int i = 0; i < A.length(); i++) {
int val = A.charAt(i);
if((val%2) == 0) {
emin = Math.min(val, emin);
emax = Math.max(val, emax);
} else {
omin = Math.min(val, omin);
omax = Math.max(val, omax);
}
}

if(Math.abs(emin - omax) != 1 || Math.abs(omin - emax) != 1 ) {
return 1;
}

return 0;
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="abcd";
		System.out.println(boringSubstring(s));
		System.out.println(solve(s));
	}

}
