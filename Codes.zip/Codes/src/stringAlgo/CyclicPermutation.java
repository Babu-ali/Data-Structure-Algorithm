package stringAlgo;

public class CyclicPermutation {
	private static int[] z;
	private static int cylicPermutation(String A, String B, String s) {
		int ans=0;
		zArray(s);
		for(int i : z) {
			if(i==A.length()) {
				ans++;
			}
		}
		
		return ans;
	}
	private static void zArray(String s) {
		z=new int[s.length()];
		int L=0, R=0,p1=0;
		int n=s.length();
		for(int i=1;i<n;i++) {
			if(i>R) {
				L=i;
				R=i;
				p1=0;
				
				while(R<n && s.charAt(p1)==s.charAt(R)) {
					R++;
					p1++;
				}
				R--;
				z[i]=R-L+1;
			}else {
				int j=i-L;
				if(z[j]<(R-i+1)) {
					z[i]=z[j];
				}else {
					L=i;
					R++;
					p1=R-L;
					while(R<n && s.charAt(p1)==s.charAt(R)) {
						R++;
						p1++;
					}
					R--;
					z[i]=R-L+1;
				}
			}
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String A="1001";
		String B="0011";
		
		String s= A+"$"+B+B.substring(0, B.length()-1);
		System.out.println(cylicPermutation(A, B, s));
	}

}
