package stringAlgo;

import java.util.Arrays;

public class PeriodicString {
private static int[] z;
private static int n, j;
private static int periodicString(String A) {
	zArray(A);
	int ans=n;
	for(int i=1;i<n;i++) {
		if(z[i]+i==n) {
			return i;
		}
	}
	return ans;
}

private static void zArray(String A) {
	z=new int[A.length()];
	int L=0, R=0,p1=0;
	n=A.length();
	for(int i=1;i<n;i++) {
		if(i>R) {
			L=i;
			R=i;
			p1=0;
			
			while(R<n && A.charAt(p1)==A.charAt(R)) {
				R++;
				p1++;
			}
			R--;
			z[i]=R-L+1;
		}else {
			j=i-L;
			if(z[j]<(R-i+1)) {
				z[i]=z[j];
			}else {
				L=i;
				R++;
				p1=R-L;
				while(R<n && A.charAt(p1)==A.charAt(R)) {
					R++;
					p1++;
				}
				R--;
				z[i]=R-L+1;
			}
		}
	}
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="abcabcabc";
		zArray(s);
		System.out.println(Arrays.toString(z));
		System.out.println("Answer"+periodicString(s));
	}

}
