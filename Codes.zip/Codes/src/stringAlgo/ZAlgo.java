package stringAlgo;

import java.util.Arrays;

public class ZAlgo {
private static int[] constructZArray(String s, int[] zArray) {
	
	int L=0, R=0, n=zArray.length;
	int p1, j;
	for(int i=1;i<n;i++) {
		if(i>R) {
			L=i;
			R=i;
			p1=0;
			
			while(R<n && s.charAt(p1)==s.charAt(R)) {
				R++;
				p1++;
			}
			R--;
			zArray[i]=R-L+1;
		}else {
			j=i-L;
			if(zArray[j]<(R-i+1)) {
				zArray[i]=zArray[j];
			}else {
				L=i;
				p1=R-i+1;
				R++;
				while(R<n && s.charAt(p1)==s.charAt(R)) {
					R++;
					p1++;
				}
				R--;
				zArray[i]=R-L+1;
			}
			
		}
	}
	return zArray;
}

public static void main(String[] args) {
	String s="abcabcababcabcdb";
	int[] zArray= new int[s.length()];
	constructZArray(s, zArray);
	System.out.println(Arrays.toString(zArray));
}
}
