package MultiThreading;

public class PrintUsingTwoThreads {
	static int count=1;
	static int n;
	
	public void printOdd() {
		synchronized (this) {

			while(count<n) {
				while(count%2==0) {
					try {
						wait();
					} catch (Exception e) {
						// TODO: handle exception
						System.out.println(e);
					}
				}
				System.out.println("Number :" +count);
				count++;
				notify();
			}
			
		}
	}
	
	public void printEven() {
		
		synchronized(this) {
			while(count<n) {
				while(count%2==1) {
					try {
						wait();
					} catch (Exception e) {
						// TODO: handle exception
						System.out.println(e);
					}
				}
				System.out.println("Number :"+count);
				count++;
				notify();
			}
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		count=1;
		n=10;
		PrintUsingTwoThreads obj = new PrintUsingTwoThreads();
		
		Thread t1 = new Thread(new Runnable() {
			public void run() {
				obj.printOdd();
			}
		});
		
		Thread t2 = new Thread(new Runnable() {
			public void run() {
				obj.printEven();
			}
		});
		
		t1.start();
		t2.start();
		

	}

}
