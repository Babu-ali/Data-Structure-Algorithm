package MultiThreading;

public class PrintUsingThreeThreads {

	private volatile int count=1;
	private volatile int threadToRun=1;
	private Object object = new Object();
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		PrintUsingThreeThreads obj = new PrintUsingThreeThreads();
		
		Thread t1 = new Thread(obj.new Printer(1));
		Thread t2 = new Thread(obj.new Printer(2));
		Thread t3 = new Thread(obj.new Printer(3));

		t1.start();
		t2.start();
		t3.start();
	}
	
	class Printer implements Runnable {
		private int threadId;
		public Printer(int threadId) {
			super();
			this.threadId = threadId;
		}
		
		public void run() {
			try {
				while(count<=20) {
					synchronized(object) {
						if(threadId != threadToRun)
							object.wait();
						else {
							System.out.println("Thread Id: "+threadId+ " printed : "+count);
							count++;
							
							if(threadId ==1)
								threadToRun =2;
							if(threadId ==2)
								threadToRun =3;
							if(threadId ==3)
								threadToRun =1;
							
							object.notifyAll();
			
						}
					}
				}
			} catch (Exception e) {
				// TODO: handle exception
				System.out.println(e );
			}
		}
		
	}

}
