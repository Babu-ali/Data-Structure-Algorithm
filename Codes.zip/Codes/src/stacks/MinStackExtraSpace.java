package stacks;

import java.util.Stack;

public class MinStackExtraSpace {
	Stack<Integer> stack = new Stack<Integer>();
	Stack<Integer> auxStack = new Stack<>();
	void push(int x) {
		if(stack.isEmpty()) {
			stack.push(x);
			auxStack.push(x);
			return;
		}
		if(x<=auxStack.peek()) {
			stack.push(x);
			auxStack.push(x);
			
		}else {
			stack.push(x);
			auxStack.push(auxStack.peek());
		}
	}
	
	void pop() {
		if(stack.isEmpty()) {
			System.out.println("Stack is empty");
			return;
		}
		stack.pop();
		auxStack.pop();
	}
	
	int getMin() {
		return auxStack.peek();
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MinStackExtraSpace ms = new MinStackExtraSpace();
		ms.push(2);
		ms.push(5);
		ms.push(3);
		ms.push(1);
		System.out.println(ms.getMin());
		ms.pop();
		System.out.println(ms.getMin());
		ms.pop();
		System.out.println(ms.getMin());
	}

}
