package stacks;

import java.util.Arrays;
import java.util.Stack;

public class Solution {
//    static int[] prevSmall;
//    static int[] nextSmall;
//    static int[] prevGreater;
//    static int[] nextGreater;
//    static void prevSmallIdx(int[] A, int n){
//        prevSmall = new int[n];
//        Arrays.fill(prevSmall, -1);
//
//        Stack<Integer> stack = new Stack<Integer>();
//        for(int i=n-1;i>=0;i--){
//            if(stack.isEmpty() || A[i]>=A[stack.peek()]){
//                stack.push(i);
//            }else{
//                while(!stack.isEmpty() && A[i]<A[stack.peek()]){
//                    prevSmall[stack.pop()] = i;
//                }
//                stack.push(i);
//            }
//        }
//    }
//
//    static void nextSmallIdx(int[] A, int n){
//        nextSmall = new int[n];
//        Arrays.fill(nextSmall, n);
//
//        Stack<Integer> stack = new Stack<Integer>();
//        for(int i=0;i<n;i++){
//            if(stack.isEmpty() || A[i]>=A[stack.peek()]){
//                stack.push(i);
//            }else{
//                while(!stack.isEmpty() && A[i]<A[stack.peek()]){
//                    nextSmall[stack.pop()] = i;
//                }
//                stack.push(i);
//            }
//        }
//    }
//
//    static void prevGreaterIdx(int[] A, int n){
//        prevGreater = new int[n];
//        Arrays.fill(prevGreater, -1);
//
//        Stack<Integer> stack = new Stack<Integer>();
//
//        for(int i=n-1;i>=0;i--){
//            if(stack.isEmpty() || A[i]<=A[stack.peek()]){
//                stack.push(i);
//            }else{
//                while(!stack.isEmpty() && A[i]>A[stack.peek()]){
//                    prevGreater[stack.pop()] = i;
//                }
//                stack.push(i);
//            }
//        }
//    }
//
//    static void nextGreaterIdx(int[] A, int n){
//        nextGreater = new int[n];
//        Arrays.fill(nextGreater,n);
//
//        Stack<Integer> stack = new Stack<Integer>();
//
//        for(int i=0;i<n;i++){
//            if(stack.isEmpty() || A[i]<=A[stack.peek()]){
//                stack.push(i);
//            }else{
//                while(!stack.isEmpty() && A[i]>A[stack.peek()]){
//                    nextGreater[stack.pop()] = i;
//                }
//                stack.push(i);
//            }
//        }
//
//    }
    
    static int[] prevSmall;
    static int[] nextSmall;
    static long area=0;
    static void prevSmallIdx(int[] A, int n){
        prevSmall = new int[n];
        Arrays.fill(prevSmall, -1);
        Stack<Integer> stack = new  Stack<Integer>();
        for(int i=n-1;i>=0;i--){
            if(stack.isEmpty() || A[i]>=A[stack.peek()]){
                stack.push(i);
            }else{
                while(!stack.isEmpty() && A[i]<A[stack.peek()]){
                    prevSmall[stack.pop()] = i;
                }
                stack.push(i);
            }
        }
    }

    static void nextSmallIdx(int[] A, int n){
        nextSmall = new int[n];
        Arrays.fill(nextSmall, n);
        Stack<Integer> stack = new  Stack<Integer>();
        for(int i=0;i<n;i++){
            if(stack.isEmpty() || A[i]>=A[stack.peek()]){
                stack.push(i);
            }else{
                while(!stack.isEmpty() && A[i]<A[stack.peek()]){
                    nextSmall[stack.pop()] = i;
                }
                stack.push(i);
            }
        }
    }
    static int largestRectangle(int[] A, int n){
        prevSmallIdx(A, n);
        nextSmallIdx(A, n);
        int mod = 1000*1000*1000+7;
        for(int i=0;i<n;i++){
            int r=nextSmall[i];
            int l=prevSmall[i];
            long width = (1L*(r-l-1))%mod;
            area = Math.max(area, (A[i]*width)%mod);
        }
        return (int)area;
    }

    public static void main(String[] args) {
		int A[] = {2,1,5,6,2,3};
		int n=A.length;
//		prevSmallIdx(A,n);
//		nextSmallIdx(A, n);
//		prevGreaterIdx(A, n);
//		nextGreaterIdx(A, n);
//		System.out.println(Arrays.toString(prevSmall));
//		System.out.println(Arrays.toString(nextSmall));
////		System.out.println(Arrays.toString(nextSmallerIndex(A)));
//		System.out.println(Arrays.toString(prevGreater));
//		System.out.println(Arrays.toString(nextGreater));
		
		System.out.println(largestRectangle(A, n));
		System.out.println(Arrays.toString(prevSmall));
		System.out.println(Arrays.toString(nextSmall));
		
		
	}
}

