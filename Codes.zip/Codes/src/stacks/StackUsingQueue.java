package stacks;

public class StackUsingQueue {

}
