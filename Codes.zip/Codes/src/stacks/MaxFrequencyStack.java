package stacks;

import java.util.HashMap;
import java.util.Map;
import java.util.Stack;

public class MaxFrequencyStack {

	Map<Integer, Integer> freqMap;
	Map<Integer, Stack<Integer>> freqStack;
	int maxFreq;
	
	public MaxFrequencyStack() {
		freqMap = new HashMap<Integer, Integer>();
		freqStack = new HashMap<Integer, Stack<Integer>>();
		maxFreq=0;
	}
	
	int push(int x) {
		int freq = freqMap.getOrDefault(x, 0)+1;
		freqMap.put(x, freq);
		maxFreq = Math.max(freq, maxFreq);
		
		if(!freqStack.containsKey(freq)) {
			Stack<Integer> s = new Stack<>();
			s.push(x);
			freqStack.put(freq, s);
		}else {
			Stack<Integer> s = freqStack.get(freq);
			s.push(x);
			freqStack.put(freq, s);
		}
		return -1;
		
	}
	
	int pop() {
		Stack<Integer> s = freqStack.get(maxFreq);
		int top = s.pop();
		if(s.isEmpty()) {
			maxFreq--;
		}
		freqMap.put(top, freqMap.get(top)-1);
		return top;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MaxFrequencyStack m = new MaxFrequencyStack();
		m.push(5); //5
		m.push(7); //4
		m.push(5); //7
		m.push(7); //5
		m.push(4); //7
		m.push(5); //5
		System.out.println(m.pop());
		System.out.println(m.pop());
		System.out.println(m.pop());
		System.out.println(m.pop());
				
	
	}
}
