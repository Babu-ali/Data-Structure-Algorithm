package stacks;

public class StackUsingLinkedList {

		Node head;
		int size=0;
		class Node {
			int data;
			Node next;
			
			Node(int data){
				this.data = data;
				this.next = null;
			}
		}
		void push(int x) {
			size++;
			Node newNode = new Node(x);
			newNode.next = head;
			head = newNode;
		}
		void pop() throws Exception {
			if(head == null) {
				throw new Exception("Stack underflow");
			}
			size--;
			System.out.println(head.data +" has been removed");
			head = head.next;
		}
		
		int getSize() {
			return size;
		}
		
		boolean isEmpty() {
			return head == null;
		}
		
		int top() {
			if(head == null) {
				System.out.println("stack underflow");
				return -1; 
			}else {
				return head.data;
			}
		}
		
		public static void main(String[] args) throws Exception {
			StackUsingLinkedList stack = new StackUsingLinkedList();
			stack.push(1);
			stack.push(2);
			stack.push(3);
			stack.push(4);
			System.out.println("Top element "+stack.top());
			System.out.println(stack.getSize());
			stack.pop();
			stack.pop();
			stack.pop();
			stack.pop();
			System.out.println(stack.getSize());
//			stack.pop();
		}
}
