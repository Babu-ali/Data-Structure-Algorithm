package stacks;

import java.util.Stack;

public class BalanceParentheses {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String A = "[({})]";
		String B = "[({)}]";
		Stack<Character> stack = new Stack<>();
		
		for(int i=0;i<A.length();i++) {
			char x = A.charAt(i);
			if(x =='[' || x =='(' || x =='{') {
				stack.push(x);
				continue;
			}
			if(stack.isEmpty()) {
				System.out.println("Unbalanced 1");
				return;
			}
			char check;
			switch(x) {
			case ']' :
				check = stack.pop();
				if(check == '(' || check == '{') {
					System.out.println("Unbalanced 2");
					return;
				}
				break;
				
			case ')' :
				check = stack.pop();
					if(check == '{' || check == '[') {
						System.out.println("Unbalanced 3");
						return;
					}
					break;
			
			case '}' :
				check = stack.pop();
				if(check == '(' || check == '[') {
					System.out.println(check);
					System.out.println("Unbalanced 4");
					return;
				}
				break;
				
			default :
				System.out.println("Unexpected bracket : Unbalanced 5");
				return;
			}
			
		}
		if(stack.isEmpty()) {
			System.out.println("Parentheses are balanced");
		}
	}

}
