package stacks;

import java.util.ArrayList;
import java.util.EmptyStackException;
import java.util.Stack;

public class MinStackNoExtraSpace {
	Stack<Integer> stack = new Stack<>();
	int minEle = Integer.MAX_VALUE;
	
	 public void push(int x) {
	        if(stack.isEmpty()) {
				minEle = x;
				stack.push(x);
				return;
			}
			if(x>=minEle) {
				stack.push(x);
				return;
			}
			stack.push(2*x-minEle);
			minEle=x;
			return;
	    }

	    public void pop() {
	        if(stack.isEmpty()) {
				return;
			}
			if(stack.peek()>=minEle) {
				stack.pop();
				return;
			}
			minEle = 2*minEle-stack.peek();
			stack.pop();
	    }

	    public int top() {
	        if(stack.isEmpty()) {
				return -1;
			}
			if(stack.peek()<=minEle) {
				return minEle;
			}
			return stack.peek();
	    }

	    public int getMin() {
	        if(stack.isEmpty()) {
	        	return -1;
	        }
	        return minEle;
	    }


	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
//		19 P 10 P 9 g P 8 g P 7 g P 6 g p -g p -g p -g p -g p- g
		MinStackNoExtraSpace s = new MinStackNoExtraSpace();
		s.push(19);
		s.push(10);
		s.push(9);
		System.out.println(s.getMin());
		s.push(8);
		System.out.println(s.getMin());
		s.push(7);
		System.out.println(s.getMin());
		s.push(6);
		System.out.println(s.getMin());
		s.pop();
		System.out.println(s.getMin());
		s.pop();
		System.out.println(s.getMin());
		s.pop();
		System.out.println(s.getMin());
		s.pop();
		System.out.println(s.getMin());
		s.pop();
		System.out.println(s.getMin());
		
	}

}
