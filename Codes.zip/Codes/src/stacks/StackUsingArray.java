package stacks;

public class StackUsingArray {
	static int top=-1;
	static int[] stack = new int[100];

	static boolean isEmpty() {
		System.out.println((top<0 ? "stack is empty" : "stack isn't empty"));
		return (top<0);
	}
	
	static boolean push(int x) {
		if(top>=stack.length-1) {
			System.out.println("Stack overflow");
			return false;
		}else {
			stack[++top]=x;
			System.out.println(x +" pushed in stack");
			return true;
		}
	}
	
	static int pop() {
		if(top<0) {
			System.out.println("stack underflow");
			return 0;
		}else {
			int x=stack[top--];
			return x;
		}
	}
	
	static int peek() {
		if(top<0) {
			System.out.println("stack underflow");
			return 0;
		}else {
			System.out.println("Top of stack "+stack[top]);
			return stack[top];
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		push(1);
		push(2);
		push(3);
		push(4);
		push(5);
		pop();
		pop();
		isEmpty();
		peek();
		pop();
		pop();
		pop();
		isEmpty();
		peek();
	}

}
