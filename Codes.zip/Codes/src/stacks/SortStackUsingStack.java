package stacks;

public class SortStackUsingStack {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
