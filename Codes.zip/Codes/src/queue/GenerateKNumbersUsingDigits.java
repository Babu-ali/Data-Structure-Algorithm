package queue;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;

public class GenerateKNumbersUsingDigits {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int A[] = {1,2,3};
		Deque<String> deq = new ArrayDeque<>();
		ArrayList<String> list = new ArrayList<>();
		for(Integer i : A) {
			deq.add(String.valueOf(i));
			list.add(String.valueOf(i));
		}
		int size = A.length;
		int k=10;
		while(list.size()<k) {
			String str = deq.getFirst();
			for(Integer i : A) {
				if(list.size()==k)
					break;
				deq.add(str+i);
				list.add(str+i);
			}
			deq.removeFirst();
		}
		System.out.println(list);
//		System.out.println(deq);
		
	}

}
