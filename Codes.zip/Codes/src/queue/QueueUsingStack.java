package queue;

import java.util.Stack;

public class QueueUsingStack {
	
	static Stack<Integer> s1;
	static Stack<Integer> s2;
	
	static void enqueue(int x) {
		s1.push(x);
	}
	
	static int dequeue() {
		if(!s2.isEmpty()) {
			
			return s2.pop();	
		}
		while(!s1.isEmpty()) {
			s2.push(s1.pop());
		}
		return s2.pop();
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		s1 = new Stack<>();
		s2 = new Stack<Integer>();
		enqueue(1);
		enqueue(2);
		enqueue(3);
		System.out.println("Dequeue "+dequeue());
		System.out.println("Dequeue "+dequeue());
		enqueue(4);
		enqueue(5);
		System.out.println("Dequeue "+dequeue());
		System.out.println("Dequeue "+dequeue());
	}

}
