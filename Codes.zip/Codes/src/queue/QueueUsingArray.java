package queue;

public class QueueUsingArray {
	static int f=0;
	static int r=0;
	static int arr[];
	static int size;
	
	static void enqueue(int x) {
		if(r==arr.length) {
			System.out.println("Queue overflow");
			return;
		}
		size++;
		arr[r]=x;
		r++;
	}
	
	static int dequeue() {
		if(isEmpty()) {
			System.out.println("Queue underflow");
			return -1;
		}
		size--;
		return arr[f++];
	}
	
	static int front() {
		if(isEmpty()) {
			System.out.println("Queue underflow");
			return -1;
		}
		return arr[f];
	}
	
	static boolean isEmpty() {
		return size<=0;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		arr= new int[10];
		f=0;
		r=0;
		size=0;
		enqueue(2);
		enqueue(3);
		enqueue(4);
		enqueue(5);
		System.out.println("front "+front());
		
		System.out.println("dequeue");
		System.out.println(dequeue());
		System.out.println("front "+front());
		System.out.println(dequeue());
		System.out.println(dequeue());
		System.out.println(dequeue());
		System.out.println(dequeue());
		System.out.println(isEmpty());
	}

}
