package queue;

public class DoubleEndedQueueUsingArray {
	static int front=-1;
	static int rear =-1;
	static int arr[] = new int[10];
	static int n = arr.length;
	
	static boolean isEmpty() {
		if(front == -1 && rear == -1) {
			return true;
		}
		return false;
	}
	
	static boolean isFull() {
		if(front == (rear+1) || (front == 0 && rear == n-1)) {
			return true;
		}
		return false;
	}
	
	static void addFirst(int x) {
		if(isFull()) {
			System.out.println("Queue is full");
			return;
		}
		if(isEmpty()) {
			front++;
			rear++;
			arr[front]=x;
			return;
		}
		if(front==0) {
			front = n-1;
			arr[front]=x;
			return;
		}
		front--;
		arr[front]=x;
		return;
		
	}
	
	static void addLast(int x) {
		if(isFull()) {
			System.out.println("Queue is full");
			return;
		}
		if(isEmpty()) {
			front++;
			rear++;
			arr[rear]=x;
			return;
		}
		if(rear==n-1) {
			rear = 0;
			arr[rear]=x;
			return;
		}
		rear++;
		arr[rear]=x;
		return;
	}
	
	static int removeFirst() {
		int temp=front;
		if(isEmpty()) {
			System.out.println("Queue underflow");
			return -1;
		}
		if(front == rear) {
			front = -1;
			rear = -1;
			return arr[temp];
		}
		if(front==n-1) {
			
			front=0;
			return arr[temp];
		}
		front++;
		return arr[temp];
	}
	
	static int removeLast() {
		int temp=rear;
		if(isEmpty()) {
			System.out.println("Queue underflow");
			return -1;
		}
		if(front == rear) {
			front = -1;
			rear = -1;
			return arr[temp];
		}
		if(rear == 0) {
			rear = n-1;
			return arr[temp];
		}
		rear--;
		return arr[temp];
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		front=-1;
		rear =-1;
		arr = new int[10];
		n = arr.length;
		
	}

}
