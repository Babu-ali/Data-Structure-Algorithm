package queue;

import java.util.ArrayList;
import java.util.Deque;
import java.util.LinkedList;
import java.util.List;

public class TaskScheduling {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Deque<Integer> deq	= new LinkedList<>();
		
		int A[] = {1};
		int B[] = {1};
		
		for(Integer i : A) {
			deq.add(i);
		}
		int n = B.length;
		int ans=0;
		for(int i=0;i<n;i++) {
			int task = B[i];
//			if(task!=A[i]) {
				while(deq.getFirst()!=task) {
					deq.addLast(deq.removeFirst());
					ans++;
				}
				deq.removeFirst();
				ans++;
//			}else {
//				ans++;
//				deq.removeFirst();
//			}
		}
		System.out.println(ans);
	}

}
