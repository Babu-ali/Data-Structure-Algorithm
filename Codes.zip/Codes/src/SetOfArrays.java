import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.TreeSet;

public class SetOfArrays {
	public static void main(String[] args) {
//	    Set<List<String>> boog = new TreeSet<List<String>>();
////	    		new TreeSet<>(Arrays::compare);
//	    String a="a";
//	    String b="b";
//	    ArrayList<String> list=new ArrayList<String>();
//	    list.add(a);
//	    list.add(b);
//	    boog.add(list);
////	    boog.add(list);
//	    System.out.println(boog);
//	    for (List<String> e : boog)
//	        System.out.println(e);
	    
	    Set<Integer> boog = new TreeSet<Integer>();
	    		boog.add(1);
	    		boog.add(10);
	    		boog.add(1);
	    		System.out.println(boog);
	    		
	    		Integer[] num = {7,34,45,23,23,56,21};
	    	    /*First we convert an Array to List using
	    	      Arrays.asList(), then pass the list as an
	    	      argument to the constructor of TreeSet */
	    	    List<Integer> list = Arrays.asList(num);
	    	    Set<Integer> set = new TreeSet<Integer>(list);
	    	    Integer a[]= {1,2};
//	    	    set.add(a);
	    	    // Show Set elements
	    	    System.out.println("The Set elements are :");
//	    	    for(Integer var : set)
	    	        System.out.println(set);
	    	        
	    	        TreeMap t=new TreeMap();
	    	        
	    	        t.put(1, 100);
	    	        
	    	        SortedMap<String, String> tm
	                = new TreeMap<String, String>();
	      
	            // Adding elements into the TreeMap
	            // using put()
//	    	    Integer arr[]= {1,2};
	    	    int arr[]= {1,2,4};
	    	    int []brr= {1,2,3};
	    	    StringBuilder s= new StringBuilder("");
	    	    s.append(arr[0]);
	    	    s.append(arr[1]);
//	    	    s.append(arr[2]);
	    	    
	            tm.put(s.toString(), "1");
	            s.setLength(0);
	            s.append(brr[0]);
	            s.append(brr[1]);
	            s.append(brr[2]);
	            tm.put(s.toString(), "3");
//	            tm.put("India", "10");
	            System.out.println(tm.size());
	            for(Map.Entry<String, String> e : tm.entrySet() ) {
	            	System.out.println(e.getKey());
	            }
	            System.out.println(tm.toString());
	            
	            TreeMap<int[], String> map = new TreeMap<>(Arrays::compare);
	            map.put(arr, "babu");
	            map.put(brr, "Ali");
	            System.out.println(map);
	            
	            
	            Map<int[], String> treeMap = new TreeMap<>((o1, o2) -> {
	                for (int i = 0; i < o1.length; i++) {
	                    if (o1[i] > o2[i]) {
	                        return 1;
	                    } else if (o1[i] < o2[i]) {
	                        return -1;
	                    }
	                }

	                return 0;
	            });
	            
	            treeMap.put(arr, "babu");
	            treeMap.put(brr, "Ali");
	            System.out.println(treeMap);
	    	  
	}
}
