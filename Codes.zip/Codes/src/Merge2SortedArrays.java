import java.util.Arrays;

public class Merge2SortedArrays {
public static int [] mergeArrays(int [] A, int [] B) {
	int [] mergedArray = new int[A.length + B.length];
	int p1=0, p2=0, i=0;
	while(p1<A.length && p2<B.length) {
		if(A[p1]<B[p2]) {
			mergedArray[i]=A[p1];
			p1++;
			i++;
		}else {
			mergedArray[i]=B[p2];
			p2++;
			i++;
		}
	}
	while(p1<A.length) {
		mergedArray[i]=A[p1];
		p1++;
		i++;
	}
	while(p2<B.length) {
		mergedArray[i]=B[p2];
		p2++;
		i++;
	}
	return mergedArray;
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int []A = {4, 7, 9 };
		int []B = {2 ,11, 19 };
		System.out.println(Arrays.toString(mergeArrays(A, B)));
	}

}
