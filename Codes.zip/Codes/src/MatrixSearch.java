
public class MatrixSearch {
static int row=-1;
static boolean found=false;
public static int binarySearchCol(int A[][], int B) {
	int element=0;
	if(B>(A[A.length-1][A[0].length-1]) || B<A[0][0]) {
		return element;
	}
	int low=0, high=A.length-1;
	int col=A[0].length-1;
	while(low<=high) {
		int mid=low+(high-low)/2;
		if(A[mid][col]==B) {
			found=true;
			return element=1;
		}else if(A[mid][col]<B) {
			low=mid+1;
		}else {
			high=mid-1;
		}
		
		
	}
	row=high+1;
	if(!found) {
		element=binarySearchRow(A, B);
	}
	return element;
}

public static int binarySearchRow(int A[][], int B) {
	int element=0;
	int low=0, high=A[row].length-1;
	while(low<=high) {
		int mid=low+(high-low)/2;
		if(A[row][mid]==B) {
			return element=1;
		}else if(A[row][mid]<B) {
			low=mid+1;
		}else {
			high=mid-1;
		}
		
		
	}
	return element;
}

public static int matrixSearch(int A[][], int B) {
	return binarySearchCol(A,B);
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int A[][]=new int[3][4];
		int k=1;
		int B=7;
		for(int i=0;i<A.length;i++) {
			for(int j=0;j<A[0].length;j++) {
				A[i][j]=k++;
				System.out.println(A[i][j]);
			}
		}
		System.out.println(matrixSearch(A,B));
		System.out.println(found);
		System.out.println("row :"+row);

	}

}

//Another approach

//public int searchMatrix(int[][] A, int B) {
//    int n = A.length, m = A[0].length;
//    //assume all elements are added to a list and after that it is sorted
//    //last index will be n * m - 1
//    int low = 0, high = n * m - 1, ans = -1;
//    while(low <= high){
//        int mid = (high - low) / 2 + low;
//        int row = mid / m, col = mid % m;
//        if(A[row][col] > B) 
//            high = mid - 1;
//        else{
//            ans = mid;
//            low = mid + 1;
//        }
//    }
//    if(ans == -1 || A[ans / m][ans % m] != B) 
//        return 0;
//    return 1;
//}
