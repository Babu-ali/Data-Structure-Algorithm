package geekForGeek;

public class PoliceStation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=4, a=2;
		int x[]= {10,4,2,17};
//		2 4 10 17
//		8 15
		
		int ans=Integer.MIN_VALUE;
		int ans2=Integer.MIN_VALUE;
		
		for(int i=0;i<x.length;i++) {
			x[i]=Math.abs(x[i]-a);
		}
		for(int i=0;i<x.length;i++) {
			if(x[i]>ans) {
				ans2=ans;
				ans=x[i];
				
			}else if(x[i]>ans2 && x[i] !=ans) {
				ans2=x[i];
			}
		}
//		for(int i=0;i<x.length;i++) {
//			if(x[i]>ans2 && x[i]<ans) {
//				ans2=x[i];
//			}
//		}
		System.out.println(ans);
		System.out.println(ans2);
		System.out.println("Answer : "+(ans+ans2));
	}

}
