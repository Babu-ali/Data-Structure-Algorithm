import java.util.Arrays;

public class SumTheDiffMaxMinSubSequence {
public static void power(int powOf2[]) {
	powOf2[0]=1;
	for(int i=1;i<powOf2.length;i++) {
		powOf2[i]=powOf2[i-1]*2;
	}
}
public static long diff(int A[], int pow[]) {
	long ans=0;
	for(int i=0;i<A.length;i++) {
		ans+=A[i]*(pow[i] - pow[A.length-i-1]);
	}
	return ans;
}



	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int A[]= {1,2,3};
		Arrays.sort(A);
		long powOf2[]=new long[A.length];
		powOf2[0]=1;
		int i=1;
		while(i<A.length) {
			powOf2[i]=(powOf2[i-1]*2)%1000000007;
			i++;
		}
		System.out.println(Arrays.toString(powOf2));
		long ans=0;
		for(int j=0;j<A.length;j++) {
			long diff=(powOf2[j]-powOf2[A.length-j-1]);
			ans=(ans+(A[j]*diff)%1000000007)%1000000007;
		}
		System.out.println(ans);
	}

}
