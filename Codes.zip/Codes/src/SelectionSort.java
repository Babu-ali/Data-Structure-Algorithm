import java.util.Arrays;

public class SelectionSort {

public static void selectionSort(int A[]) {
	for(int i=0;i<A.length-1;i++) {
		int min_idx=i;
		for(int j=i+1;j<A.length;j++) {
			if(A[j]<A[min_idx]) {
				min_idx=j;
			}
		}
		int temp=A[i];
		A[i]=A[min_idx];
		A[min_idx]=temp;
	}
	
	System.out.println(Arrays.toString(A));
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int A[]= {5,18,20,21,1,4,2,3};
		selectionSort(A);
	}

}
