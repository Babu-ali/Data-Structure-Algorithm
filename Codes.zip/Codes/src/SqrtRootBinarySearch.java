
public class SqrtRootBinarySearch {

public static int sqrt(long a) {
	long low=0, high=a, ans=0;
	while(low<=high) {
		long mid=low+(high-low)/2;
		if(mid*mid<=a) {
			ans=mid;
			low=mid+1;
		}else {
			high=mid-1;
		}
	}
	
	
	return (int)ans;
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(sqrt(0));
	}

}
