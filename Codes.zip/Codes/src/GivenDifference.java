import java.util.Arrays;

public class GivenDifference {

public int givenDiff(int A[], int B) {
	int N = A.length;
    int count=0;
    int i=0, j=1;
    Arrays.sort(A);
    int pair2 = -1, pair1 = -1;
    while(j<N){
        int diff = Math.abs(A[j] - A[i]);
        if(diff == B){
            if(pair1 != A[j] && pair2 != A[i]){
                count++;
                pair1 = A[j];
                pair2 = A[i];
            }

            i++;
            j++;
        }else if(diff > B){
            i++;
            if(i==j){
                j++;
            }
        }else{
            j++;
        }
    }
    return count;
}
	public static void main(String[] args) {
		int A[] = {1, 8, 2, 8, 8, 8, 8, 4, 4, 6, 10, 10, 9, 2, 9, 3, 7};
		int B = 1;
		GivenDifference obj=new GivenDifference();
		System.out.println(obj.givenDiff(A, B));
//		System.out.println(countPairsWithDiffK(A,A.length,B));
		

	}

}
