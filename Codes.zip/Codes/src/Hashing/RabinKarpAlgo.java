package Hashing;

import java.util.Arrays;

public class RabinKarpAlgo {

	private static void rabinKarp(String pat, String text) {
		int power[] = new int [pat.length()];
		int k=26, mod=1000000007, hash_pat=0, hash_text=0;
		int ans=0;
		power[0]=1;
		for(int i=1;i<pat.length();i++) {
			power[i]=k*power[i-1];
		}
		
		for(int i=0;i<pat.length();i++) {
			hash_pat=(hash_pat + (pat.charAt(i)*power[pat.length()-1-i])%mod)%mod;
			hash_text=(hash_text+(text.charAt(i)*power[pat.length()-1-i])%mod)%mod;
		}
//		System.out.println(Arrays.toString(power));
		System.out.println("hash_pat"+hash_pat);
		System.out.println("hash_text"+hash_text);
		
		if(hash_pat==hash_text && pat.contentEquals(text.substring(0, pat.length()))) {
			ans++;
		}
		
		for(int i=pat.length();i<text.length();i++) {
			hash_text=(hash_text - ((text.charAt(i-pat.length())*power[pat.length()-1])%mod)+mod)%mod;
			hash_text=(hash_text*k)%mod;
			hash_text=(hash_text+text.charAt(i))%mod;
			
			if(hash_pat == hash_text && pat.contentEquals(text.substring(i-pat.length()+1, i+1))) {
				ans++;
			}
		}
		System.out.println("text"+text.substring(0, pat.length()));
		System.out.println("ans"+ans);
		
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String pat="abcd";
		String text="abcdabcddfgdgabcd";
		rabinKarp(pat, text);
	}

}
