package Hashing;

import java.util.ArrayList;
import java.util.HashMap;

public class CommonElements {

	private static int [] commonElements(int A[], int B[]) {
		ArrayList<Integer> list = new ArrayList<>();
		HashMap<Integer, Integer> map = new HashMap<Integer, Integer>();
		int ans[];
		if(A.length>B.length) {
			for(int i=0;i<A.length;i++) {
				if(!map.containsKey(A[i])) {
					map.put(A[i], 1);
				}else {
					map.put(A[i], map.get(A[i])+1);
				}
			}
			for(int j=0;j<B.length;j++) {
				if(map.containsKey(B[j])) {
					list.add(B[j]);
					if(map.get(B[j])>1) {
						map.put(B[j], map.get(B[j])-1);
					}else {
						map.remove(B[j]);
					}
				}
			}
			
		}else {
			for(int i=0;i<B.length;i++) {
				if(!map.containsKey(B[i])) {
					map.put(B[i], 1);
				}else {
					map.put(B[i], map.get(B[i])+1);
				}
			}
			for(int j=0;j<A.length;j++) {
				if(map.containsKey(A[j])) {
					list.add(A[j]);
					if(map.get(A[j])>1) {
						map.put(A[j], map.get(A[j])-1);
					}else {
						map.remove(A[j]);
					}
				}
			}
		}
		ans=new int[list.size()];
		for(int i=0;i<list.size();i++) {
			ans[i]=list.get(i);
		}
		System.out.println(list);
		return ans;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int A[]= {1, 2, 2, 1};
		int B[]= {2, 3, 1, 2};
		commonElements(A,B);
	}

}
