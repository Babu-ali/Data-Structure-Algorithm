package Hashing;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Anagrams {

	 private static ArrayList<ArrayList<Integer>> returnAnagrams(List<String> A){
	        HashMap<HashMap<Character,Integer>, ArrayList<Integer>> bMap = new HashMap<HashMap<Character,Integer>, ArrayList<Integer>>();
	        int j=0;
	        for(String str : A){
	            HashMap<Character,Integer> fMap = new HashMap<Character,Integer>();
	            for(int i=0;i<str.length();i++){
	                if(fMap.containsKey(str.charAt(i))){
	                    fMap.put(str.charAt(i), fMap.get(str.charAt(i))+1);
	                }else{
	                    fMap.put(str.charAt(i),1);
	                }
	            }
	            if(!bMap.containsKey(fMap)){
	                ArrayList<Integer> list = new ArrayList<Integer>();
	                list.add(j);
	                bMap.put(fMap, list);
	            }else{
	                ArrayList<Integer> list = bMap.get(fMap);
	                list.add(j);
	                bMap.put(fMap,list);
	            }
	            j++;
	        }
	        ArrayList<ArrayList<Integer>> finalList = new ArrayList<ArrayList<Integer>>();
	        for(ArrayList<Integer> val : bMap.values()){
	            finalList.add(val);
	        }
	        return finalList;
	    }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<String> list = new ArrayList<String>();
		list.add("cat");
		list.add("tac");
		list.add("act");
		list.add("ball");
		list.add("abll");
//		String A[]= {"cat","tac","act","ball","abll"};
		System.out.println(returnAnagrams(list));

	}

}
