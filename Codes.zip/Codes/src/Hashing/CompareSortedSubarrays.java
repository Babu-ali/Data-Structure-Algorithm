package Hashing;

import java.util.Arrays;
import java.util.HashMap;

public class CompareSortedSubarrays {
	private static HashMap<Integer, Long> map = new HashMap();
	private static long prefix[];
	private static void setValues(int[] A) {
		long range = 1000*1000*1000*1000;
		int n=A.length;
		for(int i=0;i<n;i++) {
			long setValue= (long)(Math.random()*range+1);
			if(!map.containsKey(A[i])) {
				map.put(A[i], setValue);
			}
		}
	}
	private static void prefixSum(int A[]) {
		prefix=new long[A.length];
		prefix[0]=map.get(A[0]);
		
		for(int i=1;i<A.length;i++) {
			prefix[i]=prefix[i-1]+map.get(A[i]);
		}
	}
	
	private static int[] compareSortedArrays(int A[], int B[][]) {
		int res[]=new int[B.length];
		
		for(int i=0;i<B.length;i++) {
			int query[] = B[i];
			int L1=query[0], R1=query[1], L2=query[2], R2=query[3];
			if(R1-L1==R2-L2) {
				long sum1=0, sum2=0;
				if(L1==0) {
					sum1=prefix[R1];
				}else {
					sum1=prefix[R1]-prefix[L1-1];
				}
				
				if(L2==0) {
					sum2=prefix[R2];
				}else {
					sum2=prefix[R2]-prefix[L2-1];
				}
				if(sum1==sum2) {
					res[i]=1;
				}
			}
			
		}
		
		return res;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int A[]= {1, 7, 11, 8, 11, 7, 1};
		int B[][]= {{0, 2, 4, 6}};
		int n=A.length;
		setValues(A);
		prefixSum(A);
		
        System.out.println(Arrays.toString(prefix));
        System.out.println(prefix[A.length-1]-prefix[3]);
        System.out.println(Arrays.toString(compareSortedArrays(A, B)));
	}

}
