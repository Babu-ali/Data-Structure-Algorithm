package Hashing;

import java.util.HashMap;

public class RightAngledTriangle {

private static int rightTriangle(int A[], int B[]) {
	long count=0;
	int mod=1000000007;
	HashMap<Integer, Integer> frequencyX = new HashMap<Integer, Integer>();
	HashMap<Integer, Integer> frequencyY = new HashMap<Integer, Integer>();
	
	for(int i=0;i<A.length;i++) {
		if(frequencyX.containsKey(A[i])) {
			frequencyX.put(A[i], frequencyX.get(A[i])+1);
		}else {
			frequencyX.put(A[i], 1);
		}
		
		if(frequencyY.containsKey(B[i])) {
			frequencyY.put(B[i], frequencyY.get(B[i])+1);
		}else {
			frequencyY.put(B[i], 1);
		}
		
	}
	for(int j=0;j<A.length;j++) {
		count=(count+((frequencyX.get(A[j])-1) * (frequencyY.get(B[j])-1))%mod)%mod;
	}
	
	return (int)count;
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int A[]= {1, 1, 2, 3, 3};
		int B[]= {1, 2, 1, 2, 1};
		System.out.println(rightTriangle(A,B));
		
	}

}
