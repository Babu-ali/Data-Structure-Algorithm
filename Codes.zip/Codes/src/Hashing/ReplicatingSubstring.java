package Hashing;

public class ReplicatingSubstring {

	private static int replicateSubstring(int A, String B) {
		int freq[] = new int[26];
		for(int i=0;i<B.length();i++) {
			freq[B.charAt(i)-'a']+=1;
		}
		for(int i=0;i<freq.length;i++) {
			if(freq[i]%A!=0)
				return -1;
		}
		
		return 1;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String B="aaebb";
		int A=2;
		System.out.println(replicateSubstring(A, B));
		
		
	}

}
