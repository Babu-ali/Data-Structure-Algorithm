package Hashing;

import java.util.HashSet;

public class ColourfulNumber {

	private static int colourfulNumber(int A) {
		HashSet<Integer> set = new HashSet<Integer>();
		int n=10, prev=-1;
		
		while(A>0) {
			int curr=A%n;
			A/=n;
			if(set.isEmpty()) {
				set.add(curr);
				prev=curr;
				continue;
			}
			if(set.contains(curr)) return 0;
			set.add(curr);
			
			if(set.contains(curr*prev)) return 0;
			set.add(curr*prev);
			prev=curr;
			
		}
		return 1;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int A=23;
		System.out.println(colourfulNumber(A));	
	}
}
