package Hashing;

import java.util.Arrays;

public class PermutationsAinB {
	static int max=26;
	private static int permutationOfAinB(String A, String B) {
		int count=0;
		int countA[]=new int [26];
		int countB[]=new int [26];
		int m=A.length();
		int n=B.length();
		
		for(int i=0;i<m;i++) {
			countA[A.charAt(i)-'a']++;
			countB[B.charAt(i)-'a']++;
		}
		int j=0;
		for(int i=m;i<n;i++) {
			if(compare(countA, countB)) {
				count++;
			}
			countB[B.charAt(i)-'a']++;
			countB[B.charAt(j)-'a']--;
			j++;
		}
		if(compare(countA, countB)) {
			count++;
		}
		return count;
	}
	private static boolean compare(int countA[], int countB[]  ) {
		for(int i=0;i<max;i++) {
			if(countA[i]!=countB[i]) {
				return false;
			}
		}
		return true;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String txt = "acaa";
        String pat = "aca";
        System.out.println(permutationOfAinB(pat, txt));
	}

}
