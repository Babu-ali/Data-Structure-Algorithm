package Hashing;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class OracleTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		List<Integer> list = new ArrayList<Integer>();
		int sum =0;
		list.add(1);
		list.add(10);
		list.add(100);
		list.add(500);
		list.add(-500);
		list.add(-200);
		list.add(500);
		
		for(int i=0;i<list.size();i++) {
			String s = list.get(i).toString();
			if(s.length()==3 || ( s.charAt(0)=='-' && s.length()==4)) {
				sum+=list.get(i);
			}
		}
		System.out.println("Sum : "+sum);

	}
}
