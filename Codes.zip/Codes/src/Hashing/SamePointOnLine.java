package Hashing;

import java.util.HashMap;

public class SamePointOnLine {

	private static int samePointOnLine(int A[], int B[]) {
		int maxCount=0;
		for(int i=0;i<A.length;i++) {
			HashMap<String, Integer> map = new HashMap<String, Integer>();
			int count = 1;
			int curr_max=0;
			String key="";
			for(int j=0;j<A.length;j++) {
				if(i!=j) {
					if(A[i]==A[j] && B[i]==B[j]) {
						count++;
					}else {
						int numerator=B[j]-B[i];
						int denominator=A[i]-A[j];
						int gcd = findGCD(numerator, denominator);
						
						key= ""+(numerator/gcd)+"-"+(denominator/gcd);
						if(map.containsKey(key)) {
							map.put(key, map.get(key)+1);
						}else {
							map.put(key, 1);
						}
					}
					curr_max=Math.max(curr_max, count);
					if(map.containsKey(key)) {
						curr_max=Math.max(curr_max, count+map.get(key));
					}
				}
			}
			maxCount=Math.max(maxCount, curr_max);
		}
		
		return maxCount;
	}
	
	private static int findGCD(int a, int b) {
		if(b==0) {
			return a;
		}
		return findGCD(b, a%b);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int A[]= {3, 1, 4, 5, 7, -9, -8, 6};
		int B[]= {4, -8, -3, -2, -1, 5, 7, -4};
		
		System.out.println(samePointOnLine(A, B));

	}

}
