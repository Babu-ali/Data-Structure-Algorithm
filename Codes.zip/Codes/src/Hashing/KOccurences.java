package Hashing;
import java.util.HashMap;
import java.util.HashSet;
public class KOccurences {

	private static int kSum(int A, int B, int C[]) {
		long sum=0;
		boolean exist=false;
		HashMap<Integer, Integer> map = new HashMap<Integer, Integer>();
		HashSet<Integer> set = new HashSet<Integer>();
		for(int i=0;i<C.length;i++) {
			if(map.containsKey(C[i])) {
				map.put(C[i], map.get(C[i])+1);
			}else {
				map.put(C[i], 1);
			}
			set.add(C[i]);
		}
		for(int j=0;j<C.length;j++) {
			if(map.containsKey(C[j])) {
				if(map.get(C[j])==B) {
					exist=true;
					sum=(sum+C[j])%1000000007;
				}
				map.remove(C[j]);
			}
			
		}
		if(!exist) {
			return -1;
		}
		
		return (int)sum;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int A=5 ,B=2 ,C[]= {0,0,3};
		System.out.println(kSum(A,B,C));
	}

}
