package Hashing;

import java.util.Arrays;
import java.util.HashMap;

public class SubArrayWithZeroSum {

	private static int [] SubArrayWithZeroSum(int A[]) {
		int start=-1, end=-1, length=Integer.MIN_VALUE, sum=0, ans[], k=0;
		HashMap<Integer, Integer> map = new HashMap<Integer, Integer>();
		map.put(0, -1);
		for(int i=0;i<A.length;i++) {
			sum+=A[i];
			
			if(!map.containsKey(sum)) {
				map.put(sum, i);
			}else{
				if((i-map.get(sum))>length) {
					start=map.get(sum)+1;
					end=i;
					length=(i-map.get(sum));
				}
			}
		}
		
		if(start==-1 && end==-1) {
			int ansEmpty[]= {};
			return ansEmpty;
		}
		ans=new int[end-start+1];
		for(int i=start;i<=end;i++) {
			ans[k]=A[i];
			k++;
		}
		return ans;
				
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int A[]= {10, -3, -9, -10, 9, -26, 7, -2, -20, -19, -9, 7, 13, -5, -8, -24, -11, 28, 28, 24 };
		System.out.println(Arrays.toString(SubArrayWithZeroSum(A)));
	}

}
