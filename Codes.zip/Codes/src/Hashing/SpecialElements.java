package Hashing;

import java.util.HashMap;

public class SpecialElements {

private static int SpecialElements(int A[]) {
	HashMap<Integer, Integer> map = new HashMap<Integer, Integer>();
	int distance=Integer.MAX_VALUE;
	
	for(int i=0;i<A.length;i++) {
		if(!map.containsKey(A[i])) {
			map.put(A[i], i);
		}else {
			
			if((i-map.get(A[i]))<distance) {
				distance=(i-map.get(A[i]));
			}
			map.put(A[i], i);
		}
	}
	
	if(distance==Integer.MAX_VALUE) {
		return -1;
	}
	return distance;
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int A[]= {1,1};
		System.out.println(SpecialElements(A));
	}

}
