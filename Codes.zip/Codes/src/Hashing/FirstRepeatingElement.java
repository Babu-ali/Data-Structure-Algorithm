package Hashing;

import java.util.HashMap;

public class FirstRepeatingElement {

private static int firstRepeatingEle(int A[]) {
	int idx=Integer.MAX_VALUE;
	HashMap<Integer, Integer> map = new HashMap<>();
	for(int i=0;i<A.length;i++) {
		if(!map.containsKey(A[i])) {
			map.put(A[i],i);
		}else {
			if(map.get(A[i])<idx) {
				idx=map.get(A[i]);
			}
		}
	}
	if(idx==Integer.MAX_VALUE) {
		return -1;
	}
	return A[idx];
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int A[]= {6, 10, 5, 4, 9, 120};
		System.out.println(firstRepeatingEle(A));
	}

}
