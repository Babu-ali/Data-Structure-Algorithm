package Hashing;

import java.util.HashSet;

public class Rectangle {

	private static int rectangle(int A[], int B[]) {
		int count=0;
		HashSet<String> set = new HashSet<String>();
		for(int i=0;i<A.length;i++) {
			String key=A[i]+"|"+B[i];
			set.add(key);
		}
		for(int i=0;i<A.length-1;i++) {
			int x1=A[i], y1=B[i];
				for(int j=i+1;j<B.length;j++) {
					int x2=A[j], y2=B[j];
					
					if(x1==x2 || y1==y2) {
						continue;
					}
					if(set.contains(x1+"|"+y2) && set.contains(x2+"|"+y1)) {
						count++;
					}
					
				}
				set.remove(x1+"|"+y1);
		}
		
		return count;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int A[]= {1, 1, 2, 2, 3, 3};
		int B[]= {1, 2, 1, 2, 1, 2};
		System.out.println(rectangle(A,B));
	}

}
