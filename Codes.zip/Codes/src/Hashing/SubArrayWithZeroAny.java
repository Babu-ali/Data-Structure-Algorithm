package Hashing;

import java.util.HashMap;
import java.util.HashSet;

public class SubArrayWithZeroAny {

private static int subArrayZero(int A[]) {
	HashSet<Long> map= new HashSet<Long>();
	long sum=0;
	
	for(int i=0;i<A.length;i++) {
		sum+=A[i];
		if(map.contains(sum) || sum==0) {
			return 1;
		}else {
			map.add(sum);
		}
	}
	
	return 0;
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int A[]= {1,-1};
		String str="hello";
		String str2=str;
		System.out.println(str);
		System.out.println(str2);
		str="goodbye";
		System.out.println(str);
		System.out.println(str2);
		System.out.println(subArrayZero(A));
	}

}
