package Hashing;

import java.util.HashSet;

public class Palindrome {

	private static int checkPalindrome(String A) {
		HashSet<Character> set = new HashSet<Character>();
		for(int i=0;i<A.length();i++) {
			if(set.contains(A.charAt(i))) {
				set.remove(A.charAt(i));
			}else {
				set.add(A.charAt(i));
			}
		}
		if((A.length() & 1)==set.size()) {
			return 1;
		}
		return 0;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String A="aaebbb";
		System.out.println(checkPalindrome(A));
	}

}
