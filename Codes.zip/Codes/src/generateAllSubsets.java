

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.stream.IntStream;

public class generateAllSubsets {
static ArrayList<ArrayList<Integer>> list;
static ArrayList<Integer> temp;
private static void subSets(int ind, int n, Integer arr[]) {
	if(ind==n) {
		list.add(new ArrayList<>(temp));
		return;
	}
	//Don't include A[i]
	subSets(ind+1, n, arr);
	//Include A[i]
	temp.add(arr[ind]);
	subSets(ind+1, n, arr);
	temp.remove(temp.size()-1);
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		list = new ArrayList<ArrayList<Integer>>();
		temp=new ArrayList<Integer>();
		int A[]= {7,3,6};
		Integer arr[]=new Integer[A.length];
		// To boxed array
		for(int i=0;i<A.length;i++) {
			arr[i]=A[i];
		}
//		Integer[] what = Arrays.stream( A ).boxed().toArray( Integer[]::new );
//		Integer[] ever = IntStream.of( A ).boxed().toArray( Integer[]::new );
//		Arrays.sort(arr, Collections.reverseOrder());
//		Arrays.sort(arr);
		subSets(0, A.length, arr);
		Collections.sort(list, new Comparator<ArrayList<Integer>>() {
			public int compare(ArrayList<Integer> list1, ArrayList<Integer> list2) {
				System.out.println(list1 + "and " +list2);
				int len=0;
				if(list1.size()<list2.size()) {
					len=list1.size();
				}else {
					len=list2.size();
				}
				int check=0;
				for(int i=0;i<len;i++) {
					check=list1.get(i).compareTo(list2.get(i));
					if(check==0){
						
					}else {
						return list1.get(i).compareTo(list2.get(i));
					}
				}
				return check;
			}
		});
		System.out.println(list);
	}

}
