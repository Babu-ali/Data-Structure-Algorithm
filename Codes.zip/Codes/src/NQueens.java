import java.util.ArrayList;
import java.util.HashSet;

public class NQueens {
	public static ArrayList<ArrayList<String>> ans;
	public static HashSet<Integer> rowSet = new HashSet<>();
	public static HashSet<Integer> colSet;
	public static HashSet<Integer> leftDiagonal;
	public static HashSet<Integer> rightDiagonal;
public static void nQueens(int row, int n, ArrayList<ArrayList<String>> board, char arr[][] ) {
	if(row==n) {
		board.add(construct(arr));
		return;
	}
	
	for(int col=0;col<n;col++) {
		if(!rowSet.contains(row) && !colSet.contains(col) && !leftDiagonal.contains(row+col) && !rightDiagonal.contains(row-col)) {
			arr[row][col]='Q';
			rowSet.add(row);
			colSet.add(col);
			leftDiagonal.add(row+col);
			rightDiagonal.add(row-col);
			nQueens(row+1,n, board, arr);
			arr[row][col]='.';
			rowSet.remove(row);
			colSet.remove(col);
			leftDiagonal.remove(row+col);
			rightDiagonal.remove(row-col);
		}
	}
}
public static ArrayList<String> construct(char arr[][]){
	ArrayList<String> res = new ArrayList<>();
	for(int i=0;i<arr.length;i++) {
		String s= new String(arr[i]);
		res.add(s);
	}
	return res;
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=4;
		char arr[][]=new char[n][n];
		for(int i=0;i<n;i++) {
			for(int j=0;j<n;j++) {
				arr[i][j]='.';
			}
		}
		ans = new ArrayList<>();
		 rowSet = new HashSet<>();
		 colSet = new HashSet<>();
		leftDiagonal = new HashSet<>();
		 rightDiagonal = new HashSet<>();
		 nQueens(0, n, ans, arr);
		System.out.println(ans);
		 

	}

}
