package list;

public class mergeSort {
	Node head; 
	int size=0;
	public class Node {
		int data;
		Node next;
		
		Node(int data){
			this.data = data;
			this.next = null;
		}
	}
	
	void addLast(int data) {
		Node newNode = new Node(data);
		size++;
		if(head == null) {
			head = newNode;
			return;
		}
		
		Node lastNode = head;
		
		while(lastNode.next != null) {
			lastNode = lastNode.next;
		}
		
		lastNode.next = newNode;
	}
	
	void printList() {
		Node currNode = head;
		
		while(currNode != null) {
			System.out.print(currNode.data +" -> ");
			currNode = currNode.next;
		}
		System.out.println("null");
	}
	
	
	
	int getSize() {
		return size;
	}
	
	static Node getMiddle(Node head) {
		Node slow = head;
		Node fast = head;
		
		while(fast.next != null && fast.next.next != null) {
			slow = slow.next;
			fast = fast.next.next;
		}
		return slow;
	}
	
	Node sortedMerge(Node left, Node right) {
		Node result = null;
		if(left == null) {
			return right;
		}
		if(right == null) {
			return left;
		}
		
		if(left.data<right.data) {
			result = left;
			result.next = (sortedMerge(left.next, right));
		}else {
			result = right;
			result.next = sortedMerge(left, right.next);
		}
		return result;
	}
	
	Node mergeSortAlgo(Node head) {
		if(head == null || head.next == null) {
			return head;
		}
		
		Node mid = getMiddle(head);
		Node nextofMid = mid.next;
		mid.next = null;
		
		Node left = mergeSortAlgo(head);
		Node right = mergeSortAlgo(nextofMid);
		
		Node sortedList = sortedMerge(left, right);
		
		return sortedList;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		mergeSort ll = new mergeSort();
		
		
		ll.addLast(1);
		ll.addLast(3);
		ll.addLast(2);
		ll.addLast(4);
		ll.printList();
		ll.head = ll.mergeSortAlgo(ll.head);
		ll.printList();
		
		
	}

}
