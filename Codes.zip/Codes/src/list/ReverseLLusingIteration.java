package list;

public class ReverseLLusingIteration {
	static Node head;
	class Node {
		int data;
		Node next;
		
		Node(int data){
			this.data = data;
			next = null;
		}
	}
	
	void push(int x) {
		Node newNode = new Node(x);
		if(head == null) {
			head = newNode;
			return;
		}
		Node curr = head;
		while(curr.next != null) {
			curr = curr.next;
		}
		curr.next = newNode;
	}
	
	public void print() {
		Node curr = head;
		while(curr!= null) {
			System.out.println(curr.data);
			curr = curr.next;
		}
	}

	public Node reverseLL(Node head) {
		if(head == null || head.next == null) {
			return head;
		}
		
		Node prev = null;
		Node curr = head;
		Node nxt = null;
		
		while(curr != null) {
			nxt = curr.next;
			curr.next = prev;
			prev = curr;
			curr = nxt;
			
		}
		head = prev;
		return head;
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ReverseLLusingIteration ll 	= new ReverseLLusingIteration();
		ll.push(1);
		ll.push(2);
		ll.push(3);
		ll.push(4);
		ll.push(5);
		System.out.println("print LL");
		ll.print();
		System.out.println("Reverse");
		head = ll.reverseLL(head);
		ll.print();
		
	}

}
