package list;

public class MergeTwoSortedList {
	Node head1;
	Node head2;
	int size=0;
	public class Node {
		int data;
		Node next;
		
		Node(int data){
			this.data = data;
			this.next = null;
		}
	}
	
	void addLast1(int data) {
		Node newNode = new Node(data);
		size++;
		if(head1 == null) {
			head1 = newNode;
			return;
		}
		
		Node lastNode = head1;
		
		while(lastNode.next != null) {
			lastNode = lastNode.next;
		}
		
		lastNode.next = newNode;
	}
	
	void addLast2(int data) {
		Node newNode = new Node(data);
		size++;
		if(head2 == null) {
			head2 = newNode;
			return;
		}
		
		Node lastNode = head2;
		
		while(lastNode.next != null) {
			lastNode = lastNode.next;
		}
		
		lastNode.next = newNode;
	}
	
	void printList(Node head) {
		Node currNode = head;
		
		while(currNode != null) {
			System.out.print(currNode.data +" -> ");
			currNode = currNode.next;
		}
		System.out.println("null");
	}
	
	public static Node mergeTwoLL(Node h1, Node h2) {
		Node head=null, tail=null;
		Node p1=h1, p2=h2;
		
		if(p1.data<p2.data) {
			head = p1;
			tail = p1;
			p1 = p1.next;
		}
		else {
			head = p2;
			tail = p2;
			p2=p2.next;
		}
		
		while(p1!= null && p2!= null) {
			if(p1.data<p2.data) {
				tail.next = p1;
				tail=p1;
				p1 = p1.next;
			}
			else {
				tail.next = p2;
				tail = p2;
				p2=p2.next;
			}
		}
		if(p1== null) {
			tail.next = p2;
		}else if(p2==null) {
			tail.next = p1;
		}
		
		return head;
		
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MergeTwoSortedList l1 = new MergeTwoSortedList();
		MergeTwoSortedList l2 = new MergeTwoSortedList();
		l1.addLast1(1);
		l1.addLast1(3);
		l1.addLast1(5);
		l1.addLast1(6);
		
		l2.addLast2(2);
		l2.addLast2(4);
		l2.addLast2(7);
		l2.addLast2(8);
		
		l1.printList(l1.head1);
		l2.printList(l2.head2);
		l2.printList(mergeTwoLL(l1.head1, l2.head2));
		
	}

}
