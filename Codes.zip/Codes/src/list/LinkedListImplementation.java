package list;

public class LinkedListImplementation {
	Node head; 
	int size=0;
	public class Node {
		String data;
		Node next;
		
		Node(String data){
			this.data = data;
			this.next = null;
		}
	}
	
	public void addFirst(String data) {
		size++;
		Node newNode = new Node(data);
		newNode.next = head;
		head = newNode;
	}
	
	void addLast(String data) {
		Node newNode = new Node(data);
		size++;
		if(head == null) {
			head = newNode;
			return;
		}
		
		Node lastNode = head;
		
		while(lastNode.next != null) {
			lastNode = lastNode.next;
		}
		
		lastNode.next = newNode;
	}
	
	void printList() {
		Node currNode = head;
		
		while(currNode != null) {
			System.out.print(currNode.data +" -> ");
			currNode = currNode.next;
		}
		System.out.println("null");
	}
	
	void removeFirst() {
		if(head == null) {
			System.out.println("List is empty");
			return;
		}
		size--;
		head = head.next;
	}
	
	void removeLast() {
		if(head == null) {
			System.out.println("List is empty");
			return;
		}
		size--;
		if(head.next == null) {
			head = null;
			return;
		}
		
		Node secondLastNode = head;
		Node lastNode = head.next;
		while(lastNode.next != null) {
			secondLastNode = lastNode;
			lastNode = lastNode.next;
		}
		secondLastNode.next=null;
		
	}
	
	int getSize() {
		return size;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedListImplementation ll = new LinkedListImplementation();
		ll.addFirst("is");
		ll.printList();
		System.out.println("Size "+ll.getSize());
		ll.addLast("a");
		ll.printList();
		ll.addFirst("this");
		ll.printList();
		System.out.println("Size "+ll.getSize());
		ll.removeLast();
		
		ll.printList();
	}

}
