package list;

public class LongestPalinSubList {
	Node head; 
	int size=0;
	public class Node {
		String data;
		Node next;
		
		Node(String data){
			this.data = data;
			this.next = null;
		}
	}
	
	void addLast(String data) {
		Node newNode = new Node(data);
		size++;
		if(head == null) {
			head = newNode;
			return;
		}
		
		Node lastNode = head;
		
		while(lastNode.next != null) {
			lastNode = lastNode.next;
		}
		
		lastNode.next = newNode;
	}
	
	void printList() {
		Node currNode = head;
		
		while(currNode != null) {
			System.out.print(currNode.data +" -> ");
			currNode = currNode.next;
		}
		System.out.println("null");
	}
	
	int getSize() {
		return size;
	}
	
	int longestPalinList(Node head) {
		int ans=0;
		int count = 0;
		Node prev = null;
		Node curr = head;
		Node next = null;
		Node p1 = null;
		Node p2 = null;
		
		while(curr != null) {
			next = curr.next;
			curr.next = prev;
			
			//odd length
			p1 = prev;
			p2 = next;
			count = countCommonNodes(p1, p2);
			ans = Math.max(ans, (2*count)+1);
			
			//even length
			p1 = curr;
			p2 = next;
			count = countCommonNodes(p1, p2);
			ans = Math.max(ans, (2*count));
			
			prev = curr;
			curr = next;
		}
		return ans;
	}
	
	int countCommonNodes(Node left, Node right) {
		int count = 0;
		while(left != null & right != null) {
			if(left.data == right.data) {
				count++;
				left = left.next;
				right = right.next;
			}else {
				break;
			}
			
		}
		
		return count;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LongestPalinSubList ll = new LongestPalinSubList();
		ll.addLast("a");
		ll.addLast("b");
		ll.addLast("b");
		ll.addLast("x");
		ll.addLast("a");
		ll.addLast("b");
		ll.addLast("a");
//		ll.addLast("x");
//		ll.addLast("a");
//		ll.addLast("b");
		System.out.println(ll.longestPalinList(ll.head));
		ll.printList();
		System.out.println("Size "+ll.getSize());
	}

}
