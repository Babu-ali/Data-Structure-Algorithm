package list;

import java.util.LinkedList;

public class ReverseLLusingRecursion {
	static Node head;
	class Node {
		int data;
		Node next;
		
		Node(int data){
			this.data = data;
			next = null;
		}
	}
	
	void push(int x) {
		Node newNode = new Node(x);
		if(head == null) {
			head = newNode;
			return;
		}
		Node curr = head;
		while(curr.next != null) {
			curr = curr.next;
		}
		curr.next = newNode;
	}
	
	public void print() {
		Node curr = head;
		while(curr!= null) {
			System.out.println(curr.data);
			curr = curr.next;
		}
	}

	public Node reverseLL(Node head) {
		if(head == null || head.next == null) {
			return head;
		}
		
		Node newNode = reverseLL(head.next);
		head.next.next = head;
		head.next = null;
		return newNode;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ReverseLLusingRecursion ll  = new ReverseLLusingRecursion();
		ll.push(1);
		ll.push(2);
		ll.push(3);
		ll.push(4);
		ll.push(5);
		
		ll.print();
		head = ll.reverseLL(head);
		ll.print();
		
	}

}
