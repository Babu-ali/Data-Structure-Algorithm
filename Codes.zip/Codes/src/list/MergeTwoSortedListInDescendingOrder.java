package list;

public class MergeTwoSortedListInDescendingOrder {
	Node head1;
	Node head2;
	int size=0;
	public class Node {
		int data;
		Node next;
		
		Node(int data){
			this.data = data;
			this.next = null;
		}
	}
	
	void addLast1(int data) {
		Node newNode = new Node(data);
		size++;
		if(head1 == null) {
			head1 = newNode;
			return;
		}
		
		Node lastNode = head1;
		
		while(lastNode.next != null) {
			lastNode = lastNode.next;
		}
		
		lastNode.next = newNode;
	}
	
	void addLast2(int data) {
		Node newNode = new Node(data);
		size++;
		if(head2 == null) {
			head2 = newNode;
			return;
		}
		
		Node lastNode = head2;
		
		while(lastNode.next != null) {
			lastNode = lastNode.next;
		}
		
		lastNode.next = newNode;
	}
	
	void printList(Node head) {
		Node currNode = head;
		
		while(currNode != null) {
			System.out.print(currNode.data +" -> ");
			currNode = currNode.next;
		}
		System.out.println("null");
	}
	
	public static Node mergeTwoLL(Node h1, Node h2) {
		Node head=null;
		Node p1=h1, p2=h2;
		
		while(p1!= null && p2!= null) {
			if(p1.data<p2.data) {
				Node temp = p1.next;
				p1.next = head;
				head = p1;
				p1 = temp;
			}
			else {
				Node temp = p2.next;
				p2.next = head;
				head = p2;
				p2=temp;
			}
		}
		if(p1 == null) {
			System.out.println("line 89");
			while(p2!=null) {
				Node temp = p2.next;
				p2.next = head;
				head = p2;
				p2 = temp;
			}
		}else if(p2==null) {
			System.out.println("line 97");
			while(p1!=null) {
				Node temp = p1.next;
				p1.next = head;
				head = p1;
				p1=temp;
			}
		}
		
		return head;
		
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MergeTwoSortedListInDescendingOrder l1 = new MergeTwoSortedListInDescendingOrder();
		MergeTwoSortedListInDescendingOrder l2 = new MergeTwoSortedListInDescendingOrder();
		l1.addLast1(1);
		l1.addLast1(3);
		l1.addLast1(5);
		l1.addLast1(7);
		
		l2.addLast2(2);
		l2.addLast2(4);
		l2.addLast2(6);
//		l2.addLast2(8);
		
//		l1.printList(l1.head1);
//		l2.printList(l2.head2);
		l2.printList(mergeTwoLL(l1.head1, l2.head2));
		
	}

}
