package restAPI;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.ProtocolException;
import java.net.URL;
import java.util.Scanner;

public class GetAPI {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		URL url = new URL("https://jsonmock.hackerrank.com/api/article_users?page=2");
		HttpURLConnection conn = (HttpURLConnection)url.openConnection();
		conn.setRequestMethod("GET");
		conn.connect();
		if(conn.getResponseCode() == 200) {
			Scanner scan = new Scanner(url.openStream());
			while(scan.hasNext()) {
				String temp = scan.nextLine();
				System.out.println(temp);
              	//parse json here
            }
        }
	}

}
