
public class NoOfRectangles {

public static int countRectangles(int A[], int B) {
	int count=0;
	// 2 pointers approach 
	//p1 at 0 and p2 at n-1
	//while(p1<=p2)
	//if(A[p1]*A[p2]<B), 
	// then count+=p2-p1+1 when (length,breadth) is same to (breadth, length)
	//when (2,3)!=(3,2)
	//then count+=2(p2-p1+1)-1

	return count;
}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
