
public class MaximumHeightOfStaircase {
public static int maxHeight(long n) {
	long height=(sqrt(1+((8*n)))-1)/2;
	return (int)height;
}
public static int sqrt(long n) {
	long low=1, high=n;
	long ans=1;
	if(n==0 || n==1) {
		return (int)n;
	}
	while(low<=high) {
		long h=(high-low)/2;
		long mid=(low+h)%1000000007;
		if((mid*mid)==n) {
			return (int)mid;
		}
		else if((mid*mid)<n) {
			ans=mid;
			low=mid+1;
		}else {
			high=mid-1;
		}
	}
	return (int)ans;
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int A=1000000000;
		System.out.println(maxHeight(A));
		System.out.println(sqrt(4));
	}

}
