
public class NonRepeatingElement {
public static int singleElement(int A[], int low, int high, int n) {
	int mid=0;
	
	if(n==1) {
		return A[0];
	}
	if(A[0]!=A[1]) {
		return A[0];
	}if(A[n-1]!=A[n-2]) {
		return A[n-1];
	}
		while(low<=high) {
			mid=low+(high-low)/2;
			
			if(A[mid]!=A[mid-1] && A[mid]!=A[mid+1]) {
				return A[mid];
			}
			if(A[mid]==A[mid-1]) {
				mid-=1;
			}
			if(mid%2==0) {
				low=mid+2;
			}else {
				high=mid-1;
			}
		}
		return 0;
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int A[]= {1, 1,2,2,4, 3, 3};
		System.out.println(singleElement(A,0,A.length-1,A.length));
		
	}

}
