package oracle.test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

class MovieList {
 
	int year;
	String name;
	int rating;
	
//	public int compare(MovieList m, MovieList m1) {
//		
//		if(m.rating<m1.rating) return -1;
//		if(m.rating>m1.rating) return 1;
//		else return 0;
//	}
	
	//constructor
	public MovieList(int year, String name, int rating) {
		this.year = year;
		this.name = name;
		this.rating = rating;
	}
	

}

class RatingCompare implements Comparator<MovieList>
{
    public int compare(MovieList m, MovieList m1)
    {
        if(m.rating<m1.rating) return -1;
		if(m.rating>m1.rating) return 1;
		else return 0;
    }
    
}

class NameCompare implements Comparator<MovieList>
{
    public int compare(MovieList m, MovieList m1)
    {
        return m.name.compareTo(m1.name);
    }
    
}

public class ComparatorSort{
	 
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<MovieList> list = new ArrayList<MovieList>();
		
		list.add(new MovieList(2000,"Mela",5));
		list.add(new MovieList(1995, "Joker", 5));
		list.add(new MovieList(1990,"xyz movie", 4));
		RatingCompare ratingCompare = new RatingCompare();
		Collections.sort(list, ratingCompare);
		
		for(MovieList m : list) {
			System.out.println(m.year +"  "+m.name+"  "+m.rating);
		}
		
		NameCompare nameCompare = new NameCompare();
		Collections.sort(list, nameCompare);
		
		for(MovieList m : list) {
			System.out.println(m.name+"  "+m.year +"  "+m.rating);
		}

	}

}
