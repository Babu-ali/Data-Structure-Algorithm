package oracle.test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class OracleTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Employee> list = new ArrayList<Employee>();
		HashMap<Integer, Employee> map = new HashMap<Integer, Employee>();
//		Employee emp = new Employee();
		list.add(new Employee(1, "Babu", 004, 50000));
		list.add(new Employee(2, "Ali", 004, 40000));
		list.add(new Employee(3, "Java", 005, 10000));
		list.add(new Employee(4, "REST", 005, 40000));
		
		for(Employee e : list) {
			if(!map.containsKey(e.depId)) {
				map.put(e.depId, e);
			}else {
				int salary= map.get(e.depId).salary;
				if(salary<e.salary) {
					map.put(e.depId, e);
				}
			}
		}
//		System.out.println(list);
//		System.out.println(map);
		
		for (Integer objectName : map.keySet()) {
//			   System.out.println(objectName);
			   System.out.println(map.get(objectName).empId + " "+ map.get(objectName).empName + " "+map.get(objectName).depId + " "+map.get(objectName).salary);
			 }
			
	}

}

class Employee{
	int empId;
	String empName;
	int depId;
	int salary;
	
	public Employee(int empId,
	String empName,
	int depId,
	int salary) {
		this.empId=empId;
		this.empName = empName;
		this.depId = depId;
		this.salary = salary;
	}
}
