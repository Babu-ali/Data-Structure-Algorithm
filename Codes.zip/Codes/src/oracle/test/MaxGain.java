package oracle.test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

//class GainClass implements Comparable<GainClass>{
//	
//	int start;
//	int end;
//	int gain;
//	
//	public GainClass(int start, int end, int gain) {
//		this.start = start;
//		this.end = end;
//		this.gain = gain;
//	}
//	
//	public int compareTo(GainClass obj) {
//		return this.start - obj.start;
//	}
//}

class GainClass{
	
	int start;
	int end;
	int gain;
	
	public GainClass(int start, int end, int gain) {
		this.start = start;
		this.end = end;
		this.gain = gain;
	}
}

class myComparator implements Comparator<GainClass>{
	public int compare(GainClass obj, GainClass obj2) {
	if(obj.start<obj2.start) return -1;
	if(obj.start>obj2.start) return 1;
	return 0;
	}
}
public class MaxGain {

	 
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<GainClass> list = new ArrayList<GainClass>();
		list.add(new GainClass(2, 8, 800));
		list.add(new GainClass(4, 7, 600));
		list.add(new GainClass(5, 9, 1600));
		list.add(new GainClass(3, 6, 200));
		myComparator comp = new myComparator();
		
		Collections.sort(list, comp);
		
		for(GainClass g : list) {
			System.out.println("start :"+g.start+" end :"+g.end+" gain :"+g.gain);
		}

	}

}
