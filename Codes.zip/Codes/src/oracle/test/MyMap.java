package oracle.test;

public class MyMap<K, V> {
	
	private Entry<K, V> buckets[];
	private int capacity;
	private int size =0;
	
	private double lf=0.75;
	
//	public MyMap() {
//		this(16);
//	}
	
	public MyMap(int capacity) {
		// TODO Auto-generated constructor stub
		this.capacity = capacity;
		this.buckets = new Entry[this.capacity];
	}
	
	public void put(K key, V value) {
		if(size == capacity * lf) {
			//rehash
			Entry<K, V>[] old = buckets;
			
			capacity *= 2;
			size = 0;
			
			buckets = new Entry[capacity];
			
			for(Entry<K, V> e : old) {
				while(e != null) {
					put(e.key, e.value);
					e = e.next;
				}
			}
		}
		
		Entry<K, V> entry = new Entry(key, value);
		
		int bucket = getHash(key) % getBucketSize();
		
		Entry<K, V> existing = buckets[bucket];
		
		if(existing == null) {
			buckets[bucket] = entry;
			size++;
		}else {
			// compare the keys see if key already exists
			
			while(existing.next != null) {
				if(existing.key.equals(key)) {
					existing.value = value;
					return;
				}
				existing = existing.next;
			}
			
			if(existing.key.equals(key)) {
				existing.value = value;
			}else {
				existing.next = entry;
				size++;
			}
		}
	}
	
	public V get(K key) {
		Entry<K, V> bucket = buckets[getHash(key) % getBucketSize()];
		
		while(bucket != null) {
			if(bucket.key.equals(key)) {
				return bucket.value;
			}
			bucket = bucket.next;
		}
		return null;
		
	}
	
	public int size() {
		return size;
	}
	
	public int getBucketSize() {
		return buckets.length;
	}
	
	public int getHash(K key) {
		return (key == null ? 0 : Math.abs(key.hashCode()));
	}
	
	public String toString() {
		StringBuilder sb = new StringBuilder();
		for(Entry entry : buckets) {
			sb.append("[");
			while(entry != null) {
				sb.append(entry);
				if(entry.next != null) {
					sb.append(",");
				}
				entry = entry.next;
			}
			sb.append("]");
		}
		return "{" + sb.toString() + "}";
		
	}
	
	static class Entry<K, V>{
		K key;
		V value;
		Entry<K, V> next;
		
		public Entry(K key, V value) {
			this.key = key;
			this.value = value;
			this.next = null;
		}
		
		public K getKey() {
			return key;
		}
		
		public V getValue() {
			return value;
		}
		
		public Entry<K, V> getNext(){
			return next;
		}
		
		
		public boolean equals(Object obj) {
			if(this == obj) return true;
			
			if(obj instanceof Entry) {
				Entry entry = (Entry) obj;
				
				return key.equals(entry.getKey()) && value.equals(entry.getValue());
			}
			return false;
		}
		
		public int hashcode() {
			int hash=17;
			hash = 13 * hash + ((key == null) ? 0 : key.hashCode());
			hash = 13 * hash + ((value == null) ? 0 : value.hashCode());
			return hash;
			
		}
		
		public String toString() {
			return "{" + key + ":" + value + "}";
		}
	}
	
	public static void main(String[] args) {
		MyMap<String, String> myMap = new MyMap<>(16);
		myMap.put("USA", "Washington DC");
		myMap.put("India", "New Delhi");
		
		System.out.println(myMap.size());
		System.out.println(myMap.get("India"));
		System.out.println(myMap);
	}

}
