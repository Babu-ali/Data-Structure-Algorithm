package oracle.test;

import java.util.ArrayList;
import java.util.Collections;

class Movie implements Comparable<Movie> {
 
	int year;
	String name;
	int rating;
	
	public int compareTo(Movie m) {
		
		return this.year - m.year;
	}
	
	//constructor
	public Movie(int year, String name, int rating) {
		this.year = year;
		this.name = name;
		this.rating = rating;
	}
	

}

public class ComparableSort{
	 
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Movie> list = new ArrayList<Movie>();
		
		list.add(new Movie(2000,"Mela",5));
		list.add(new Movie(1995, "Joker", 5));
		list.add(new Movie(1990,"xyz movie", 4));
		
		Collections.sort(list);
		
		for(Movie m : list) {
			System.out.println(m.year +"  "+m.name+"  "+m.rating);
		}
		

	}

}
