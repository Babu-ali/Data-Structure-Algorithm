import java.util.ArrayList;

public class generateParenthesis2 {
public static ArrayList<String> list=new ArrayList<String>();
	public static void validParenthesis(StringBuilder s, int open, int close){
	    if(open==0 && close==0){
	        list.add(s.toString());
	        return;
	    }
	    if(open>0){
	        s.append('(');
	        validParenthesis(s,open-1,close);
	        s.deleteCharAt(s.length()-1);
	    }
	    if(close>0){
	        if(open<close){
	            s.append(')');
	            validParenthesis(s,open, close-1);
	            s.deleteCharAt(s.length()-1);
	        }
	    }
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		list=new ArrayList<String>();
        StringBuilder s=new StringBuilder("");
        validParenthesis(s,3,3);
        String arr[]=new String[list.size()];
        int i=0;
        System.out.println(list.toString());
        for(String ss : list){
            arr[i]=ss;
            i++;
        }

	}

}
