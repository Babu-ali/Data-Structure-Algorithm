
public class PeakElement {
public static int findPeak(int A[], int low, int high, int n) {
	int mid=low+(high-low)/2;
	
	if((mid==0 || A[mid-1]<=A[mid]) && (mid==n-1 || A[mid+1]<=A[mid])) {
		return A[mid];
	}
	else if(mid>0 && A[mid-1]>A[mid]) {
		return findPeak(A, low, (mid-1), n);
	}else {
		return findPeak(A, mid+1, high, n);
	}
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int A[]= {1, 2, 3, 4, 5};
		System.out.println(findPeak(A, 0, A.length-1, A.length));
	}

}
